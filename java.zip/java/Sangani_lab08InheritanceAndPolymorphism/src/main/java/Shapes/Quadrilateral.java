/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

import java.awt.Shape;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Quadrilateral extends Shapes {
    private int length;
    private int breadth;
    private int height;
    /**
     * 
     * @param length
     * @param breadth
     * @param height 
     */
    //constructors
    public Quadrilateral(int length, int breadth, int height) {
        super("Quadrilateral");
        this.length = length;
        this.breadth = breadth;
        this.height = height;
    }
    //getter methods
    public int getLength() {
        return length;
    }
    public int getBreadth() {
        return breadth;
    }
    public int getHeight() {
        return height;
    }
    public int getInternalAngle(int n) {
        return 180 / n * (n - 2);
    }
    //returning the parameters
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Shape: Quadrilateral\n");
        str.append("      Length = ").append(length).append("cm\n");
        str.append("      Breadth = ").append(breadth).append("cm\n");
        str.append("      Height = ").append(height).append("cm\n");
        str.append("      Internal Angle = ").append(getInternalAngle(4)).append("°\n");
        return str.toString();
    }
}
