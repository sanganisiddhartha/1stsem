# Siddhartha
## Thousand Pillar
The **Thousand Pillar** restaurant has **themed ambiance** and ***they serves authentic dishes***. And they provide an amazing service to their coustomers.

-----

### Favorite Dishes and places near by
1. Sweet Corn Vagetable Soup
2. Crispy corn
3. Strawberry Blossom
4. Cool Feel

* Kakatiya Zoological Park
* Kakatiya fort
* Children park

You can find mymedia file here [page](MyMedia.md)