/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class SquareTester {
    /**
     * 
     * @param args 
     */
    public static void main(String[] args)
        {
            Square Square1 = new Square(5);
            Square Square2 = new Square();
            Square2.setsideLength(4);
            System.out.println("Area and perimeter of sq1 "+Square1.getArea()+" "+Square1.getPerimeter());
            System.out.println("Area and perimeter of sq2 "+Square2.getArea()+" "+Square2.getPerimeter());
            
        }
    }
    

