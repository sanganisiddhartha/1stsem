/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public class OrdersSummary {
    
    private final ArrayList<Orders> orders;
    private String day;
    //no arg constructor
    
    public OrdersSummary() {
        this.orders = new ArrayList<>();
        this.day=day;
    }
    
    /**
     * 
     * @return discount
     */
    // discount calculation method
  private double calcDiscount(){
        double discountOne=0.0;
        for(Orders order: orders){
            discountOne += order.calcDiscount();
        }
        return discountOne;
    }
    //adding orders
  
    public void addAOrder(Orders order) {
        orders.add(order);
    }
//calculating the cost of all orders
    public double calcTotalCostOfAllOrders() {
        double totalCost = 0;
        for (Orders order : orders) {
            totalCost += order.getTotalCost();
        }
        return totalCost;
    }
 // calculating the total bill with tax
    public double calcTotalBillWithTax() {
        double discount = calcDiscount();
        double totalBill = calcTotalCostOfAllOrders()-discount;
        return totalBill + (totalBill * 0.023);
    }
    
    // printing the recipt as per sample output
   public String printReceipt() {
        StringBuilder receipt = new StringBuilder();
        
        for (Orders order : orders) {
            receipt.append(order.toString());
        }
        receipt.append("----------------------------------------------------------------------------\n");
        receipt.append("\t\t\tOrder Total :  \t$");
        receipt.append(String.format("%.2f", calcTotalCostOfAllOrders())).append("\n");
        receipt.append("\t\t\tDiscount : $").append(String.format("%.2f", calcDiscount())).append("\n");
        receipt.append("\t\t\tTax@2.3% : $").append(String.format("%.2f", ((calcTotalCostOfAllOrders()-calcDiscount()) * 0.023))).append("\n");
        receipt.append("\t\t\tTotal Amount with tax : $").append(String.format("%.2f", (calcTotalBillWithTax()))).append("\n");
        receipt.append("-----------------------------------------------------------------------------");
        return receipt.toString();
}
}