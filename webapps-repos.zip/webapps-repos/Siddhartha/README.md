Hello everyone,

* This is Siddhartha Sangani
* currently pursuing master's in ACS in North West Missouri State University

[Check my linkedin profile here](https://github.com/SiddharthaSangani)