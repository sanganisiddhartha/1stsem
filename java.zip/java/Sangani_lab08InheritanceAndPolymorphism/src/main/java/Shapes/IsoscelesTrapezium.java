/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

import java.text.DecimalFormat;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class IsoscelesTrapezium extends Shapes {
    
    private int length;
    private int breadth;
    private int height;
    /**
     * 
     * @param length
     * @param breadth
     * @param height 
     */
    //constructor
    public IsoscelesTrapezium(int length, int breadth, int height) {
        super("Isosceles Trapezium");
        this.length = length;
        this.breadth = breadth;
        this.height = height;
    }
    //getter methods
    public double getArea() {
        return ((double) height * ((length + breadth) / 2.0));
    }
    private double calculateCommonSide() {
        double temporary = (double) (length - breadth) / 2.0;
        return Math.sqrt(height * height + temporary * temporary);
    }
    public double getPerimeter() {
        double commonSide = calculateCommonSide();
        return 2 * commonSide + length + breadth;
    }
    //returning as per sample output
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Shape : ").append(getName()).append("\n");
        str.append("      Length = ").append(length).append("cm\n");
        str.append("      Breadth = ").append(breadth).append("cm\n");
        str.append("      Height = ").append(height).append("cm\n");
        str.append("      Common Side = ").append(String.format("%.2f", calculateCommonSide())).append("cm\n");
        str.append("      Area = ").append(String.format("%.2f", getArea())).append("cm2\n");
        str.append("      Perimeter = ").append(String.format("%.2f", getPerimeter())).append("cms\n");
        return str.toString();
    }
}
//    private void setName(String osceles_Trapezium) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
    

