/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rentals;

/**
* Class: 44542-04 Object Oriented Programming
* @author SIddhartha Sangani
* Description: Making sure everything works
* Due: 02/08/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import java.util.*;
public class RentalsDriver {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in );
        System.out.println("Welcome to pack your bags");
        System.out.println("Please enter what type of booking section you are looking for from the following:");
        System.out.println("1. Flight Booking");
        System.out.println("2. Book Hotel");
        System.out.println("3. Rent a Car");
        System.out.println("4. Exit");
        int choice = scanner.nextInt();
        switch(choice)
        {
            case 1:
                System.out.println("Please enter your destination city");
                String destination = scanner.next();
                System.out.println("Enter flight class \n1. First Class \n2. Business \n3. Premium Economy \n4. Economy");
                int flightClassChoice = scanner.nextInt();

                String flightClass;
                switch (flightClassChoice) {
                    case 1:
                        flightClass = "First Class";
                        break;
                    case 2:
                        flightClass = "Business";
                        break;
                    case 3:
                        flightClass = "Premium Economy";
                        break;
                    case 4:
                        flightClass = "Economy";
                        break;
                    default:
                        flightClass = "Invalid Flight Class";
                }
                System.out.println("Enter number of passengers:");
                int numOfPassengers = scanner.nextInt();
                if(numOfPassengers<=4)
                {
                System.out.println("Do you have membership pass? (true/false):");
                 boolean isMember = scanner.nextBoolean();
                 
                 boolean isFirstMember;
               if(isMember){
               System.out.println("Is this your first-time membership? (true/false):");
                isFirstMember = scanner.nextBoolean();
                   System.out.println("Is first mem : " + isFirstMember);
               PackYourBagsTravels flighttkt = new PackYourBagsTravels(destination,numOfPassengers,flightClass,isMember,isFirstMember);
               System.out.println(flighttkt.flightTktPrint(destination,flightClass,numOfPassengers,isMember,isFirstMember));             
               }
               else{
                    isFirstMember = false;
                    PackYourBagsTravels flighttkt = new PackYourBagsTravels(destination,numOfPassengers,flightClass,isMember,isFirstMember);
                     System.out.println(flighttkt.flightTktPrint(destination,flightClass,numOfPassengers,isMember,isFirstMember));
               }
                            
                }
                else
                {
                    System.out.println("Error count sorry you exceded the limit");
                }
                break;
            case 2:
                System.out.println("pls enter your name:");
                String customerName = scanner.next();
                
                System.out.println("please enter the type of hotel you want to book \n1. Onestar \n2. Twostar\n3. Threestar\n4. Fourstar\n5. Fivestar");
                String hotelType = scanner.next();
                
                System.out.println("Please enter how many nights to stay");
                int numOfNights = scanner.nextInt();
                PackYourBagsTravels hotelbooking = new PackYourBagsTravels(hotelType,numOfNights,customerName);
                System.out.println(hotelbooking.hotelTktPrint(customerName,hotelType,numOfNights));
                break;

            case 3:
                System.out.println("Enter your name:");
                customerName = scanner.next();
                System.out.println("please enter the car type that you want to rent \n1. economy \n2. compact\n3. premium\n4. suv");
                String carType = scanner.next();
                System.out.println("Enter how many days do you need it for rent:");
                int rentalDays = scanner.nextInt();
                PackYourBagsTravels booking = new PackYourBagsTravels(customerName, carType, rentalDays);
                System.out.println(booking.carTktDetails(customerName, carType, rentalDays));
                break;
                
                

                
                
        }

    }
    
}
