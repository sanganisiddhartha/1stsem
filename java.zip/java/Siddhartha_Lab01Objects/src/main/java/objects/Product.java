/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class Product {
    private String productName;
    private double price;
    private int quantity;
    private double taxPercentage;
    private double DISCOUNT;
    private double totalPrice;
    private double finalPrice;
    private double shippingCost;
    public Product (String productNameIn,double priceIn,int quantityIn, double taxPercentageIn,double shippingCostIn)
    {
        productName = productNameIn;
        price = priceIn;
        quantity = quantityIn;
        taxPercentage = taxPercentageIn;
        shippingCost = shippingCostIn;
        
    }
    public Product()
    {
        
    }
    public String getproducrtName()
    {
        return productName;
    }
    public void setproductName(String productNameIn)
    {
        this.productName = productNameIn;
    }
    public double getprice()
    {
        return price; 
    }
    public void setprice(double priceIn)
    {
        this.price=priceIn;
    }
    public int getquantity()
    {
        return quantity;
    }
    public void setquantity(int quantityIn)
    {
        this.quantity=quantityIn;
    }
    public double gettaxPercentage()
    {
        return taxPercentage;
    }
    public void settaxPercentage(double taxPercentageIn)
    {
        this.taxPercentage=taxPercentageIn;
    }
    public double getshippingCost()
    {
        return shippingCost;
    }
    public void setshippingCost(double shippingCostIn)
    {
        this.shippingCost=shippingCostIn;
    }
    public double getcalcProductTotalPrice()
    {
        double calcProductTotalPrice=(price+shippingCost)*quantity+((price+shippingCost)*quantity*taxPercentage/100);
        return calcProductTotalPrice;
    }
    public double getcalcProductFinalPrice()
    {
        double calcProductFinalPrice=(price+shippingCost)*quantity-((price+shippingCost)*quantity*DISCOUNT/100);
        return calcProductFinalPrice;
    }
    @Override
    public String toString()
    {
        return String.format("\n Enter the Product Name to be purchased : %s\n Enter the price of the Product: $%.2f\n Enter the Quantity : %d\n Enter the tax of the Product in percentage: %.2f\n Enter the Shipping Cost : $%.2f",productName,price,quantity,taxPercentage,shippingCost);
    }
}

