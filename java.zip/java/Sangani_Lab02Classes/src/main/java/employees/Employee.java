/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package employees;

/**
 * Class: 44542-NN Object Oriented Programming
* @author  Siddhartha Sangani
* Description: Making sure everything works
* Due: 01/29/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
 */
public class Employee {
    private String employeeName;
    private long empID;
    private String companyName;
    private double salary;
    private boolean isPermanent;
    private String location;
    public Employee(String employeeNameIn,long empIDIn,String companyNameIn,double salaryIn,boolean isPermanentIn,String locationIn)
    {
        employeeName = employeeNameIn;
        empID = empIDIn;
        companyName = companyNameIn;
        salary = salaryIn;
        isPermanent = isPermanentIn;
        location = locationIn;
    }

    public Employee()
    {
        System.out.println("Invoked no-argument constructor");
    }
    /**
     * no arg constructor 
     * @return 
     */
    public String getemployeeName()
    {
        return employeeName;
    }
    /**
     * 
     * @param employeeNameIn 
     */
    public void setemployeeName(String employeeNameIn)
    {
        this.employeeName=employeeNameIn;
    }
    /**
     * 
     * @return 
     */
    public long getempID()
    {
        return empID;
    }
    /**
     * 
     * @param empIDIn 
     */
    public void setempID(long empIDIn)
    {
        this.empID=empIDIn;
    }
    /**
     * 
     * @return 
     */
    public String getcompanyName()
    {
        return companyName;
    }
    /**
     * 
     * @param companyNameIn 
     */
    public void setcompanyName(String companyNameIn)
    {
        this.companyName=companyNameIn;
    }
    /**
     * 
     * @return 
     */
    public double getsalary()
    {
        return salary;
    }
    /**
     * 
     * @param salaryIn 
     */
    public void setsalary(double salaryIn)
    {
        this.salary=salaryIn;
    }
    /**
     * 
     * @return 
     */
    public boolean getisPermanent()
    {
        return isPermanent;
    }
    /**
     * 
     * @param isPermanentIn 
     */
    public void setisPermanent(boolean isPermanentIn)
    {
        this.isPermanent=isPermanentIn;
    }
    /**
     * 
     * @return 
     */
    public String getlocation()
    {
        return location;
    }
    /**
     * 
     * @param locationIn 
     */
    public void setlocation(String locationIn)
    {
        this.location=locationIn;
    }
    /**
     * 
     * @return 
     */
    @Override
    public String toString()
    {
        return String.format("\n Name of the employee: %s\n EmployeeID: %d\n Name of the company: %s\n Annual salary of the employee: $%.1f\n Is employee permanent: %b\n Location of the company %s",employeeName,empID,companyName,salary,isPermanent,location);
    }
    
    
}
