/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public class Discount {
    // no arg constructor
    private Discount() {}
    //Checking discount based on the day
    /**
     * 
     * @param day
     * @return 
     */
    public static double isDiscountPossible(String day) {
        switch (day) {
            case "Halloween":
                return 0.18;
            case "Christmas":
                return 0.24;
            case "Thanksgiving":
                return 0.09;
            default:
                return 0.00;
        }
    }
    
}
