/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package S569434.assignment04;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author  Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 02/15/24
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class SanganiPattern {
    /**
     * 
     * @param inputString 
     */
    public void printPattern(String inputString)
    {
        int n,m;
        int i,k,j;
      
        String String1 = inputString.substring(0, 6);
        int count = String1.length();
        String1=String1.toUpperCase();
        if(String1.equalsIgnoreCase("OBJECT"))
        {
            int a=0;
            for(i=0;i<count;i++)
            {
                for(j=0;j<=i;j++)
                {
                    
                    System.out.print(String1.charAt(a));
                }
                System.out.println(); 
                a++;
            }
           
        }
        String temp = inputString.substring(7,15);
        //System.out.println(temp);
       int coun = temp.length();
       
        if(temp.equalsIgnoreCase("oriented"))
        {
            int a=0;
            for (i = 0; i < coun;i++) {
            
            for (j = 0; j < coun - i - 1; j++) {
                System.out.print(" ");
            }
            
            for (k = 0; k <= i; k++) {
                
                System.out.print(temp.charAt(a) + " ");
                
            }
            System.out.println();
            a++;
        }
        }  
        String String2 = inputString.substring(16, 27);
        //System.out.println(String2);
        count = String2.length();
        String2=String2.toUpperCase();
        if(String2.equalsIgnoreCase("programming"))
        {
            for(i=count;i>=1;i--)
            {
                for(j=0;j<=i;j++)
                {
                    System.out.print(" ");
                    
                }
                for (j = 0; j <= count- i; j++) 
                {
                System.out.print(String2.charAt(j));
                }
                System.out.println(); 
            }
        }
        
    }
}