/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sangani_lab09interfacesandabstractclasses;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/29/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import java.util.Scanner;

public class Perth implements Cricket {
    private double total;
    
    // Constructor no args are passed
    public Perth() {
        total = 0.0;
    }
    
    // Getter method for calculating the total
    public double getTotal() {
        return total;
    }
    
    // Method to buy players
    public void buyPlayers() {
        Scanner sc = new Scanner(System.in);
        boolean morePlayers = true;
        
        while (morePlayers) {
            System.out.print("Enter the name of the player: ");
            String playerName = sc.nextLine();
            
            System.out.print("Enter the price of " + playerName + " (in crores): ");
            double playerPrice = sc.nextDouble();
            sc.nextLine(); // Consume newline character
            
            // Update total
            total += playerPrice;
            
            System.out.print("Do you want to enter more players (Y/N): ");
            String choice = sc.nextLine();
            
            if (!choice.equalsIgnoreCase("Y")) {
                morePlayers = false;
            }
        }
        
        sc.close();
    }
}

