/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

import java.text.DecimalFormat;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public class Orders {
    /**
     * 
     */
    private final Vegetables vegetableName;
    private final int weight_in_lb;
    private final int veggieQuantity;
    private final Fruit fruitName;
    private final Drinks drink;
    private final String drinkSize;
    private final Milkshakes milkshake;
    private final IceCreams iceCream;
    private final String icecreamSize;
    private final Desserts dessert;
    private final String day;
    private final double cost;
/**
 * 
 * @param vegetableName
 * @param weight_in_lb
 * @param veggieQuantity
 * @param fruitName
 * @param drink
 * @param drinkSize
 * @param milkshake
 * @param iceCream
 * @param icecreamSize
 * @param dessert
 * @param day 
 */
    //creating constructor for orders
    public Orders(Vegetables vegetableName, int weight_in_lb, int veggieQuantity, Fruit fruitName, Drinks drink,
            String drinkSize, Milkshakes milkshake, IceCreams iceCream, String icecreamSize, Desserts dessert,
            String day) {
        this.vegetableName = vegetableName;
        this.weight_in_lb = weight_in_lb;
        this.veggieQuantity = veggieQuantity;
        this.fruitName = fruitName;
        this.drink = drink;
        this.drinkSize = drinkSize;
        this.milkshake = milkshake;
        this.iceCream = iceCream;
        this.icecreamSize = icecreamSize;
        this.dessert = dessert;
        this.day = day;
        this.cost = calculateTotalCost();
    }
    // calculating the cost of all the items individullay
    private double calcDessertCost() {
        return dessert.getDessertPrice();
    }

    private double calcDrinkCost() {
        switch (drinkSize.toLowerCase()) {
            case "small":
                return drink.getSmall();
            case "medium":
                return drink.getMedium();
            case "large":
                return drink.getLarge();
            default:
                return 0.0;
        }
    }

    private double calcMilkshakeCost() {
        return milkshake.getMilkshakePrice();
    }

    private double calcIcecreamCost() {
        switch (icecreamSize.toLowerCase()) {
            case "small":
                return iceCream.getSmall();
            case "family":
                return iceCream.getFamily();
            case "party":
                return iceCream.getParty();
            default:
                return 0.0;
        }
    }

    private double calcFruitCost() {
        return fruitName.getFruitPrice();
    }

    private double calcVeggiesCost() {
        double cost = 0;
        switch (weight_in_lb) {
            case 2:
                cost = vegetableName.getTwo_lb();
                break;
            case 3:
                cost = vegetableName.getThree_lb();
                break;
            case 4:
                cost = vegetableName.getFour_lb();
                break;
        }
        return cost * veggieQuantity;
    }
//calculating total cost
    public double calculateTotalCost() {
        double totalCost = calcDessertCost() + calcDrinkCost() + calcMilkshakeCost() + calcIcecreamCost()
                + calcFruitCost() + calcVeggiesCost();
        return totalCost;
    }
//calculating the discount
    public double calcDiscount() {
        double discount = Discount.isDiscountPossible(day);
        return cost * discount;
    }
// total cost
    public double getTotalCost() {
        return cost;
    }
    @Override
    public String toString() {
    return "********************  ORDER DETAILS *********************"+"\n"
            + "VEGETABLE TYPE: " + vegetableName + "\n"
            + "WEIGHT: " + weight_in_lb + "\n"
            + "QUANTITY: " + veggieQuantity + "\n"
            + "FRUIT: " + fruitName.name().replace("_", " ") + "\n"
            + "DRINKS: " + drink.name().replace("_", " ") + " (" + drinkSize.toUpperCase()+ ")\n"
            + "ICE-CREAM: " + iceCream.name().replace("_", " ") + " (" + icecreamSize.toUpperCase() + ")\n"
            + "MILKSHAKES: " + milkshake.name().replace("_", " ") + "\n"
            + "DESSERTS: " + dessert.name().replace("_", " ") + "\n"
            + "DAY: " + day.toUpperCase() + "\n"
            + "COST: " + String.format("%.2f", cost) + "\n";
}

}