/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package banking;
import java.time.LocalDateTime;
/**
* Class: 44542-NN Object-Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/01/23
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public class Loan {
    /**
     * 
     */
    private double loanAmount;
    private int noOfEMIs;
    private double interestRate;
    private String status;
    private LocalDateTime loanSanctionTime;
    private String loanType;
    /**
     * 
     * @param loanType
     * @param loanAmount
     * @param noOfEMIs
     * @param loanSanctionTime 
     */
    public Loan(String loanType, double loanAmount, int noOfEMIs, LocalDateTime loanSanctionTime) {
        this.loanType = loanType;
        this.loanAmount = loanAmount;
        this.noOfEMIs = noOfEMIs;
        this.loanSanctionTime = loanSanctionTime;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }
    public int getNoOfEMIs() {
        return noOfEMIs;
    }
    public void setNoOfEMIs(int noOfEMIs) {
        this.noOfEMIs = noOfEMIs;
    }
    public double getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getLoanSanctionTime() {
        return loanSanctionTime;
    }

    public void setLoanSanctionTime(LocalDateTime loanSanctionTime) {
        this.loanSanctionTime = loanSanctionTime;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    
    @Override
    public String toString() {
        return loanType + " " + loanSanctionTime + " " + String.format("%.2f", loanAmount) + " " +
                String.format("%.2f", interestRate) + "% " + noOfEMIs + "\n" + status;
    }

     
}