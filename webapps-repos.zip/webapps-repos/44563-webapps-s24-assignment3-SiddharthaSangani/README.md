[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/qJp_9AXf)
# WebApps-F24-Assignment-3
Assignment 3 - Basic HTML
Hosted at https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment3-SiddharthaSangani/

