/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sangani_lab09interfacesandabstractclasses;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/29/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // (a) Create an object objCreator of Creator class
        Creator objCreator = new Creator();
        
        // (b) Ask a user what he/she wants to bid. 
        System.out.print("Enter what you want to bid for (Ipl/Bbl): ");
        String bidChoice = scanner.nextLine();
        
        // (c) Create an object reference variable objAuction of type Auction abstract class.
        Auction objAuction;
        
        // (d) Call createAuction() through the objCreator object and pass user’s entered choice as an argument.
        if (bidChoice.equalsIgnoreCase("Ipl")) {
            objAuction = objCreator.createAuction("Ipl");
        } else if (bidChoice.equalsIgnoreCase("Bbl")) {
            objAuction = objCreator.createAuction("Bbl");
        } else {
            System.out.println("Invalid choice. Please enter either Ipl or Bbl.");
            scanner.close();
            return;
        }
        
        // (e) Ask the user for the name of team from where he/she wants to bid.
//        System.out.print("Enter the team name from where you want to bid (Chennai/Mumbai): ");
//        String teamChoice = scanner.nextLine();
//        
        // (f) Create an object reference variable of Cricket interface.
        Cricket objBid;
        
        // (g) Call createIplAuction() or createBblAuction() method through objAuction object and assign returned value to objBid.
        if (bidChoice.equalsIgnoreCase("Ipl")) {
            System.out.print("Enter the team name from where you want to bid (Chennai/Mumbai): ");
            String teamChoice = scanner.nextLine();
            if (teamChoice.equalsIgnoreCase("Chennai")) {
                objBid = objAuction.createIplAuction("Chennai");
            } else if (teamChoice.equalsIgnoreCase("Mumbai")) {
                objBid = objAuction.createIplAuction("Mumbai");
            } else {
                System.out.println("Invalid team choice for Ipl. Please enter either Chennai or Mumbai.");
                scanner.close();
                
                return;
            }
            
        } 
        else if (bidChoice.equalsIgnoreCase("Bbl")) {
            System.out.print("Enter the team name from where you want to bid (Sydney/Perth): ");
            String teamChoice = scanner.nextLine();
            if (teamChoice.equalsIgnoreCase("Sydney")) {
                objBid = objAuction.createBblAuction("Sydney");
            } else if (teamChoice.equalsIgnoreCase("Perth")) {
                objBid = objAuction.createBblAuction("Perth");
            } else {
                System.out.println("Invalid team choice for Bbl. Please enter either Sydney or Perth.");
                scanner.close();
                return;
            }
        } else {
            System.out.println("Invalid choice. Please enter either Ipl or Bbl.");
            scanner.close();
            return;
        }
        
        // (h) Call buyPlayers() method through objBid.
        objBid.buyPlayers();
        
        // (i) Print the total price for the bidding.
        System.out.println("Total price for the bidding (in crores) is: " + objBid.getTotal());
        System.out.println("***************************************************************\n" +
                                "***************************************************************");
        scanner.close();
    }
}
