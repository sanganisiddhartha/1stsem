/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public enum Drinks {
    PEPSI(4.58, 9.15, 13.78),
    COKE(4.58, 6.98, 12.38),
    SPRITE(3.98, 6.48, 16.99),
    FANTA(3.28, 5.18, 14.23),
    CANADA_DRY(3.88, 5.70, 15.90),
    DR_PEPPER(3.98, 5.28, 10.78),
    SEVEN_UP(3.28, 6.48, 12.38),
    MTN_DEW(4.58, 5.28, 18.95),
    RED_BULL(2.68, 10.48, 20.58);
    
    // declaring the final variabels
    private final double small;
    private final double medium;
    private final double large;
    /**
     * 
     * @param small
     * @param medium
     * @param large 
     */
    // constructor
    private Drinks(double small, double medium, double large) {
        this.small = small;
        this.medium = medium;
        this.large = large;
    }
    
    //getter method
    public double getSmall() {
        return small;
    }

    public double getMedium() {
        return medium;
    }

    public double getLarge() {
        return large;
    }    

    String[] split(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
