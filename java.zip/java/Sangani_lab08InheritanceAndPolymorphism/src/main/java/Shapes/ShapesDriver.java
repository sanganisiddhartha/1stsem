/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
public class ShapesDriver {
    public static void main(String[] args) {
        ArrayList<Shapes> shape = new ArrayList<>();
        try {
            File file = new File("input.txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] dimension = line.split(" ");
                switch (dimension[0].toLowerCase()) {
                    case "quadrilateral":
                        shape.add(new Quadrilateral(Integer.parseInt(dimension[1]),
                                Integer.parseInt(dimension[2]),
                                Integer.parseInt(dimension[3])));
                        break;
                    case "square":
                        shape.add(new Shapes("Square"));
                        break;
                    case "parallelogram":
                        shape.add(new Parallelogram("Parallelogram",
                                Integer.parseInt(dimension[1]),
                                Integer.parseInt(dimension[2]),
                                Integer.parseInt(dimension[3])));
                        break;
                    case "isoscelestrapezium":
                        shape.add(new IsoscelesTrapezium(Integer.parseInt(dimension[1]),
                                Integer.parseInt(dimension[2]),
                                Integer.parseInt(dimension[3])));
                        break;
                    case "nosides":
                        shape.add(new NoSides());
                        break;
                    case "triangle":
                        shape.add(new Shapes("Triangle"));
                        break;
                    case "circle":
                        shape.add(new Circle(Integer.parseInt(dimension[1])));
                        break;
                    case "rectangle":
                        shape.add(new Shapes("Rectangle"));
                        break;
                    case "sphere":
                        shape.add(new Sphere(Integer.parseInt(dimension[1])));
                        break;
                    default:
                        System.out.println("Invalid shape type: " + dimension[0]);
                        break;
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
        for (Shapes sha : shape) {
            System.out.println(sha);
            System.out.println("*****************************************");
        }
        double minimumArea = Double.MAX_VALUE;
        double maximumArea = Double.MIN_VALUE;
        double minimumPerimeter = Double.MAX_VALUE;
        double maximumPerimeter = Double.MIN_VALUE;
        for (Shapes sha : shape) {
            double area = sha.getArea();
            double perimeter = sha.getPerimeter();
            if (area < minimumArea) {
                minimumArea = area;
            }
            if (area > maximumArea) {
                maximumArea = area;
            }
            if (perimeter < minimumPerimeter) {
                minimumPerimeter = perimeter;
            }
            if (perimeter > maximumPerimeter) {
                maximumPerimeter = perimeter;
            }
        }
        System.out.println("Minimum Area = " + minimumArea + "cm²");
        System.out.println("Maximum Area = " + String.format("%.2f", maximumArea) + "cm²");
        System.out.println("*****************************************");
        System.out.println("Minimum Perimeter = " + minimumPerimeter + "cms");
        System.out.println("Maximum Perimeter = " + String.format("%.2f", maximumPerimeter) + "cms");
        System.out.println("*****************************************");
        Shapes lateBindingExample = new Circle(10);
        System.out.println("Late Binding Polymorphism: " + lateBindingExample.getName());
        Shapes polymorphicSubstitutionExample = new Sphere(5);
        System.out.println("Polymorphic Substitution: " + polymorphicSubstitutionExample.getName());
    }
}
