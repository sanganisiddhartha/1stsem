/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public enum Vegetables {
    CARROTS(1.96, 2.45, 3.76),
    CABBAGE(4.15, 6.67, 8.29),
    CAULIFLOWER(3.47, 5.07, 6.89),
    LETTUCE(1.98, 2.56, 3.90),
    ONION(0.94, 1.98, 2.45),
    MUSHROOMS(2.08, 3.98, 4.14);
    //declaring the private variables
    private final double two_lb;
    private final double three_lb;
    private final double four_lb;
    /**
     * 
     * @param two_lb
     * @param three_lb
     * @param four_lb 
     */
    // writing the constructor
    private Vegetables(double two_lb, double three_lb, double four_lb) {
        this.two_lb = two_lb;
        this.three_lb = three_lb;
        this.four_lb = four_lb;
    }
    // getter methods
    public double getTwo_lb() {
        return two_lb;
    }

    public double getThree_lb() {
        return three_lb;
    }

    public double getFour_lb() {
        return four_lb;
    }
}
