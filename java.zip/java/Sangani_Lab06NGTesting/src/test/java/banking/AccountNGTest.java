/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package banking;

import java.time.LocalDateTime;
import java.util.ArrayList;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class AccountNGTest {
    
    private Account account;
    private Customer customer;
    private Loan loan;
    
    public AccountNGTest() {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        // Create a new Customer instance
        customer = new Customer("Sid", "Sidd", "02/02/2002", 80000);
        // Create a new Account instance
        account = new Account(123456289, customer, 2000);
        
        // Create LocalDateTime object for loanSanctionTime
        LocalDateTime loanSanctionTime = LocalDateTime.of(2002, 2, 2, 0, 0);
        
        // Create Loan instance using the new constructor
        loan = new Loan("House", 60000, 8, loanSanctionTime);
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
        // Clean up resources after each test
        customer = null;
        account = null;
        loan = null;
    }

    @Test
    public void testGetAccountNumber() {
        assertEquals(account.getAccountNumber(), 123456289);
    }

    @Test
    public void testGetCustomer() {
        assertEquals(account.getCustomer(), customer);
    }

    @Test
    public void testGetBalance() {
        assertEquals(account.getBalance(), 2000.0);
    }

    @Test
    public void testGetLoans() {
        assertNotNull(account.getLoans());
    }

    @Test
    public void testGenerateStatement() {
        // You may need to customize the expected statement based on the setup
        customer = new Customer("Sid", "Sidd", "02/02/2002", 80000);
        String generatedStatement = account.generateStatement();
        assertNotNull(generatedStatement); 
        assertTrue(generatedStatement.contains("Sid"));
        assertTrue(generatedStatement.contains("02/02/2002"));
    }

    @Test
    public void testEmiCalculator() {
        customer = new Customer("06/12/2002", "Sid", "Sidd", 80000);
       
        account = new Account(34295123, customer, 80000);
        
        
        LocalDateTime loanSanctionTime = LocalDateTime.of(2002, 06, 12, 0, 0);
        
        loan = new Loan("House", 80000, 30, loanSanctionTime);
        

        double expectedEmi = 0.0;  
        System.out.println(account.emiCalculator(loan));
        assertEquals(account.emiCalculator(loan), expectedEmi); 
    }

    @Test
    public void testEmiAmount() {
        ArrayList<Loan> loans = new ArrayList<>();
        loans.add(loan);
        double expectedTotalEmi = 0.0;  
        System.out.println(account.emiAmount(loans));
        assertEquals(account.emiAmount(loans), expectedTotalEmi);  
    }

    @Test
    public void testApplyLoan() {
        String expectedResult = "success with loan sanctioned";  
        assertEquals(account.applyLoan(loan), expectedResult);
    }
}