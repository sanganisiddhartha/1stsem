/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.nwmissouri.S569434.arrayandarraylists;

import java.util.ArrayList;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 02/25/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
*/

import java.util.ArrayList;
import java.util.List;

public class ArrayListOps {
    /**
     * 
     * @param numbersArrayList
     * @param quotesArrayList
     * @param salariesArrayList 
     */
    public static void arrayListOperations(ArrayList<Integer> numbersArrayList,ArrayList<String> quotesArrayList, ArrayList<Double> salariesArrayList) {
        // a. Print all the array elements in each ArrayList using standard for loop and enhanced for loop.
        System.out.println("*********************************************ARRAY LIST*********************************************");
        System.out.println("****************************Loading of the numbersArrayList is complete. ****************************");
        System.out.println("****************************Loading of the qoutesArrayList is complete. ****************************");
        System.out.println("****************************Loading of the salariesArrayList is complete. ****************************");
        System.out.println("*****************************Printing elements using standard for loop******************************");
        System.out.print("The numbersArrayList elements are:");
        for(int i=0;i<numbersArrayList.size();i++)
        {
            System.out.print(numbersArrayList.get(i)+" ");
        }
        System.out.println();
        //printArrayListElements(numbersArrayList);
        System.out.print("The qoutesArrayList elements are: ");
        for(int i=0;i<quotesArrayList.size();i++)
        {
            System.out.print(quotesArrayList.get(i)+" ");
        }
        System.out.println();
        //printArrayListElements(quotesArrayList);
        System.out.print("The salariesArrayList elements are:");
        for(int i=0;i<salariesArrayList.size();i++)
        {
            System.out.print(salariesArrayList.get(i)+" ");
        }
        System.out.println("");
        //printArrayListElements(salariesArrayList);

        // b. Insertion operation
        System.out.println("*****************************Printing elements using enhanced for loop******************************");
        System.out.print("The numbersArrayList elements are:");
        for(Integer numbers:numbersArrayList)
        {
            System.out.print(numbers+" ");
        }
        System.out.println("");
        
//        for(Integer numbers:numbersArrayList)
//        {
//            System.out.print(numbers+" ");
//        }
        System.out.print("The qoutesArrayList elements are: ");
        for(String quotes:quotesArrayList)
        {
            System.out.print(quotes+" ");
        }
        System.out.println();
        System.out.print("The salariesArrayList elements are:");
        for(double salaties:salariesArrayList)
        {
            System.out.print(salaties+" ");
        }
        System.out.println();
        System.out.println("******************************************Insertion operation******************************************");
        numbersArrayList.add(4, -26);
        System.out.println("After inserting new element into the numbersArrayList: " + numbersArrayList);

        // ii. Insert element “Do one thing every day that scares you.” into quotesArrayList at the end and print the array list.
        quotesArrayList.add("Do one thing every day that scares you.");
        System.out.println("After inserting new element into the qoutesArrayList:  " + quotesArrayList);

        // iii. Insert element 8767.91 into salariesArrayList at the start and print the array list.
        salariesArrayList.add(0, 8767.91);
        System.out.println("After inserting new element into the salariesArrayList:  " + salariesArrayList);
        
        // c. Update operation
        // i. Update element -26 in numbersArrayList with 74 and print the array list.
        System.out.println("******************************************Update operation******************************************");
        int index = numbersArrayList.indexOf(-26);
        if (index != -1) {
            numbersArrayList.set(index, 74);
            System.out.println("After updating the numbersArrayList:  " + numbersArrayList);
        }

        // ii. Update element “Do one thing every day that scares you” in quotesArrayList with “The only thing we have to fear is fear itself.” and print the array list.
        index = quotesArrayList.indexOf("Do one thing every day that scares you.");
        if (index != -1) {
            quotesArrayList.set(index, "The only thing we have to fear is fear itself.");
            System.out.println("After updating the qoutesArrayList : " + quotesArrayList);
        }

        // iii. Update element 8767.91 in salariesArrayList with 7473.34 and print the array list.
        index = salariesArrayList.indexOf(8767.91);
        if (index != -1) {
            salariesArrayList.set(index, 7473.34);
            System.out.println("After updating the salariesArrayList : " + salariesArrayList);
        }
        
        // d. Deletion
        // i. Delete first two elements in numbersArrayList and print the array list.
        System.out.println("******************************************Delete operation******************************************");
        numbersArrayList.subList(0, 2).clear();
        System.out.println("After deleting the first two elements in the numbersArrayList:  " + numbersArrayList);

        // ii. Delete the 2nd element in qoutesArrayList and print the array list.
        if (quotesArrayList.size() > 1) {
            quotesArrayList.remove(1);
            System.out.println("After deleting the 2nd element in the qoutesArrayList:  " + quotesArrayList);
        }

        // iii. Delete the last three elements in salariesArrayList and print the array list.
        int size = salariesArrayList.size();
        if (size >= 3) {
            salariesArrayList.subList(size - 3, size).clear();
            System.out.println("After deleting last three elements in the salariesArrayList:  " + salariesArrayList);
        }
        
        // e. Searching
        // i. Find the index of element 6 in numbersArrayList and print the array list. If not found, print “number not found”
        System.out.println("******************************************Search operation******************************************");
        index = numbersArrayList.indexOf(6);
        if (index != -1) {
            System.out.println("The index of element 6 in numbersArrayList is: " + index);
        } else {
            System.out.println("Number not found in numbersArrayList");
        }

        // ii. Find the element present at index 2 in qoutesArrayList and print the array list.
        if (quotesArrayList.size() > 2) {
            System.out.println("The element present at index 2 in qoutesArrayList is:  " + quotesArrayList.get(2));
        }

        // iii. Find the index of element 9833.45 in salariesArrayList and print the array list.
        index = salariesArrayList.indexOf(9833.45);
        if (index != -1) {
            System.out.println("The index of element 9833.45 in salariesArrayList is:  " + index);
        } else {
            System.out.println("Element not found in salariesArrayList");
        }
        
        // f. Methods
        System.out.println("**************************************Using ArrayList methods***************************************");
        // i. Modify the capacity of the salariesArrayList by using ensureCapacity() method to 50.
        
        salariesArrayList.ensureCapacity(50);

        // ii. Print the size of the numbersArrayList using size() method.
        System.out.println("Size of the numbersArrayList after ensuring its capacity to 50 is: " + numbersArrayList.size());

        // iii. Multiply each element in numbersArrayList by 3 using foreach().
        for (int i = 0; i < numbersArrayList.size(); i++) {
            numbersArrayList.set(i, numbersArrayList.get(i) * 3);
        }
        System.out.println("After multiplying each element in the numbersArrayList by 3: " + numbersArrayList);

        // iv. Print sub-list of numbersArrayList between index 1 through 4 (inclusive).
        List<Integer> subList = numbersArrayList.subList(1, Math.min(5, numbersArrayList.size()));
        for (int i = 0; i < subList.size(); i++) {
            subList.set(i, subList.get(i) / 3); // Divide each element by 3
            }
        System.out.println("The Sub-list of elements in numbersArrayList from index 1 through 4 (inclusive): " + subList);
        //System.out.println("The sub-list of elements in the numbersArrayList from index 1 through 4 (inclusive):  " + numbersArrayList.subList(1, 4));

        // v. Restore elements in the quotesArrayList in uppercase.
        for (int i = 0; i < quotesArrayList.size(); i++) {
            quotesArrayList.set(i, quotesArrayList.get(i).toUpperCase());
        }
        System.out.println("The qoutesArrayList elements in uppercase are:  " + quotesArrayList);

        // g. Questionnaire
        // In a print statement answer the following questions.
        System.out.println("Questionnaire:");
        System.out.println("i) Explain the difference between array and arraylist.");
        System.out.println("Arrays have a fixed size and can only accommodate elements of the same data type. In contrast, ArrayLists offer dynamic resizing capabilities, allowing them to adjust their size as needed. Additionally, ArrayLists can store elements of different data types within the same list");
        System.out.println("ii) How to check whether an arraylist is empty or not");
        System.out.println("You can determine whether an ArrayList is empty by using the isEmpty() method. This method returns true if the ArrayList contains no elements, indicating that it is empty.");
        System.out.println("iii) What will happen if we try to add element at position 30 in salariesArrayList.");
        System.out.println("Attempting to add an element at index 30 in the salariesArrayList will result in an IndexOutOfBoundsException. This occurs because ArrayLists use zero-based indexing, meaning the valid indices range from 0 to size()-1. If an attempt is made to access an index outside this range, the operation will fail and throw an exception");
        System.out.println("iv) What is the difference between ArrayList.remove(int index) and ArrayList.remove(Object o) ?");
        System.out.println("The method ArrayList.remove(int index) removes the element at the specified index position, whereas ArrayList.remove(Object o) removes the first occurrence of the specified object from the ArrayList, regardless of its position in the list.");

        // h. Clear Operation
        // i. At last clear all the elements in numbersArrayList, quotesArrayList, salariesArrayList and print the ArrayLists after clearing elements.
        System.out.println("******************************************Clear operation*******************************************");
        numbersArrayList.clear();
        quotesArrayList.clear();
        salariesArrayList.clear();
        System.out.println("After clearing the numbersArrayList size is: "+numbersArrayList.size());
        //printArrayListElements(numbersArrayList);
        System.out.println("After clearing the qoutesArrayList size is: "+quotesArrayList.size());
        //printArrayListElements(quotesArrayList);
        System.out.println("After clearing the salariesArrayList size is: "+salariesArrayList.size());
        //printArrayListElements(salariesArrayList);
        System.out.println("**********************************************THE END*********************************************");
    }
    /**
     * 
     * @param arrayList 
     */

//    private static void printArrayListElements(ArrayList<?> arrayList) {
//        System.out.print("ArrayList elements:");
//        for (Object element : arrayList) {
//            System.out.print(" " + element);
//        }
//        System.out.println();
//    }
}
