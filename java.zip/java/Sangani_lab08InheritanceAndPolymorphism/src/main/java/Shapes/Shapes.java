/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Shapes;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Shapes {
    private String name;
    /**
     * 
     * @param name 
     */
    //constructors
    public Shapes(String name) {
        this.name = name;
    }
    //getter methods
    public String getName() {
        return name;
    }
    public double getArea() {
        return 0.0;
    }
    public double getPerimeter() {
        return 0.0; 
    }
    //returning the parameters
    @Override
    public String toString() {
        return "Shape: " + name + "\n" +
               "Area = " + getArea() + "cm2\n" +
               "Perimeter = " + getPerimeter() + "cms";
    }
}

