/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

import java.text.DecimalFormat;


/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class Circle extends Shapes {
    
    private int radius;
    /**
     * 
     * @param radius 
     */
    //constructor
    public Circle(int radius) {
        super("Circle");
        this.radius = radius;
    }
    /**
     * 
     * @param name
     * @param radius 
     */
    //constructor
    public Circle(String name, int radius) {
        super(name);
        this.radius = radius;
    }
    //getter methods
    public int getRadius() {
        return radius;
    }
    public double getArea() {
        return Math.PI * radius * radius;
    }
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Shape : ").append(getName()).append("\n");
        str.append("    Radius = ").append(radius).append("cm\n");
        str.append("    Area = ").append(String.format("%.2f", getArea())).append("cm2\n");
        str.append("    Perimeter = ").append(String.format("%.2f", getPerimeter())).append("cms\n");
        return str.toString();
    }
}
