[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/5u0mb8O1)
# WebApps-Assignment-5 Starter Code
Hosted at -https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment5-SiddharthaSangani/drinks.html
