[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/cdqffI9o)
# WebApps-S24-Assignment-7
An assignment on java script modifying the DOM and using anonymous callback functions. <br>
Money page: https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment7-SiddharthaSangani/money.html <br>
Peresion page:https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment7-SiddharthaSangani/precision.html <br>
Divlist page: https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment7-SiddharthaSangani/divlist.html <br>

