/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

import java.text.DecimalFormat;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Sphere extends Shapes {
    private int radius;
    /**
     * 
     * @param radius 
     */
    //constructor 
    public Sphere(int radius) {
        super("Sphere");
        this.radius = radius;
    }
    //getter methods
    public int getRadius() {
        return radius;
    }
    public double getArea() {
        return 4 * Math.PI * radius * radius;
    }
    public double getVolume() {
        return (4 / 3) * Math.PI * Math.pow(radius, 3);
    }
    //returning the parameters
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Shape : ").append(getName()).append("\n");
        str.append("    Radius = ").append(radius).append("cm\n");
        str.append("    Area = ").append(String.format("%.2f", getArea())).append("cm2\n");
        str.append("    Volume = ").append(String.format("%.2f", getVolume())).append("cm3\n");
        return str.toString();
    }
}


//    private void setName(String sphere) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
