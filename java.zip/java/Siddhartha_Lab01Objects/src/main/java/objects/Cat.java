/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class Cat {
    private String name;
    private int age;
    public Cat(String namein,int agein){
        name=namein;
        age= agein;
        
    }
    public String getName()
    {
        return name;
    }
    public int getAge()
    {
        return age;
    }
    public static void main(String[] args){
        Cat myCat = new Cat("kitty",4);
        System.out.println(myCat.getName());
        System.out.println(myCat.getAge());
        
    }
    
}
