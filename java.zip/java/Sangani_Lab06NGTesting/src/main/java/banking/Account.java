/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;

import java.util.ArrayList;

/**
 *
 * @author S569434
 */
public class Account {
    private long accountNumber;
    private Customer customer;
    private double balance;
    private ArrayList<Loan> loans;

    // Creating the constructor
    public Account(long accountNumber, Customer customer, double balance) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.balance = balance;
        this.loans = new ArrayList<>();
    }

    // writing the Getter methods
    public long getAccountNumber() {
        return accountNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public double getBalance() {
        return balance;
    }

    public ArrayList<Loan> getLoans() {
        return loans;
    }

    // generate statement using the string builder
    public String generateStatement() {
        StringBuilder statement = new StringBuilder();
        statement.append("------------------------------------------------------------------------------\n");
        statement.append("Name: ").append(customer.getLastName()).append(", ").append(customer.getFirstName()).append("\n");
        statement.append("Income: $").append(customer.getIncome()).append("\n");
        statement.append("Date of Birth: ").append(customer.getDob()).append("\n");
        statement.append("Account Number: ").append(accountNumber).append("\n");
        statement.append("Account balance: $").append(balance).append("\n");
        statement.append("------------------------------------------------------------------------------\n");
        statement.append("Loan Type\t\tLoan Time\t\tLoan Amount\t\tInterest Rate\t\tNo of EMI’s\t\tStatus\n");
        for (Loan loan : loans) {
            statement.append(loan.getLoanType()).append("\t\t").append(loan.getLoanSanctionTime()).append("\t\t")
                    .append("$").append(loan.getLoanAmount()).append("\t\t").append(loan.getInterestRate()).append("%\t\t")
                    .append(loan.getNoOfEMIs()).append("\t\t").append(loan.getStatus()).append("\n");
        }
        statement.append("-------------------------------------------------------------------------------\n");
       statement.append("Total EMI per Month: $").append(String.format("%.2f", emiAmount(loans))).append("\n");
        statement.append("-------------------------------------------------------------------------------\n");
        return statement.toString();
    }

   // EMI calculator method
public double emiCalculator(Loan loan) {
    double principal = loan.getLoanAmount();
    double monthlyInterestRate = loan.getInterestRate() / (12 * 100);
    int noOfEMIs = loan.getNoOfEMIs();

    
    if (principal <= 0 || monthlyInterestRate <= 0 || noOfEMIs <= 0) {
        return 0.0; 
    }

    double emi = principal * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, noOfEMIs)
            / (Math.pow(1 + monthlyInterestRate, noOfEMIs) - 1);

    return emi;
}
 
    // EMI amount method
    public double emiAmount(ArrayList<Loan> loans) {
        double totalEMI = 0.0;
        for (Loan loan : loans) {
            totalEMI += emiCalculator(loan);
            
        }
        return totalEMI;
    }

    // apply loan method
    public String applyLoan(Loan loan) {
        double income = customer.getIncome();
        String loanType = loan.getLoanType();
        double loanAmount = loan.getLoanAmount();
        int noOfEMIs = loan.getNoOfEMIs();
        double interestRate = 0;
        String status = "";

        // checking elgibility
        if (income < 0.3 * customer.getIncome()) {
            interestRate = 0;
            status = "FAILED";
        } else {
            switch (loanType) {
                case "Car":
                    if (income < 25000 || loanAmount > 50000 || noOfEMIs > 36) {
                        interestRate = 0;
                        status = "failed with low income";
                    } else {
                        interestRate = 5;
                        status = "success with loan sanctioned";
                    }
                    break;
                case "House":
                    if (income < 50000 || loanAmount > 100000 || noOfEMIs > 60) {
                        interestRate = 0;
                        status = "failed with low income";
                    } else {
                        interestRate = 10;
                        status = "success with loan sanctioned";
                    }
                    break;
                case "Business":
                    if (income < 75000 || loanAmount > 150000 || noOfEMIs > 84) {
                        interestRate = 0;
                        status = "failed with low income";
                    } else {
                        interestRate = 15;
                        status = "success with loan sanctioned";
                    }
                    break;
                default:
                    status = "failed with low income";
            }
        }

        loan.setInterestRate(interestRate);
        loan.setStatus(status);
        loans.add(loan);

        return status;
    }
}