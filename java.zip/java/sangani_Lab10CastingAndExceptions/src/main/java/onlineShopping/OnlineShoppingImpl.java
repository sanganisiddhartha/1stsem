/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineShopping;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 04/05/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import exceptions.InvalidItemIdException;
import exceptions.InvalidQuantityIdException;
import interfaces.CartOperations;
import java.util.ArrayList;
import interfaces.Payment;


public class OnlineShoppingImpl implements CartOperations {
    private ArrayList<Items> selectedItems;
    private ArrayList<Integer> selectedQuantities;
    
    

    public OnlineShoppingImpl() {
        this.selectedItems = new ArrayList<>();
        this.selectedQuantities = new ArrayList<>();
    }
    
    /**
     * 
     * @param itemsList 
     */

    public void displayInventoryItems(ArrayList<Items> itemsList) {
        System.out.println("Items available in the inventory are as follows:");
        System.out.println("Id\tType\t\t\tPrice per item\tQuantity Available");
        for (Items item : itemsList) {
            System.out.println(item.getItemId() + "\t" + item.getItemName() + "\t\t" + item.getItemPrice() + "\t\t\t" + item.getAvailableQuantity());
        }
    }
    /**
     * 
     * @param item
     * @param quantity 
     */
    public void addItemsToCart(Items item, int quantity) {
        selectedItems.add(item);
        selectedQuantities.add(quantity);
    }
    public int calculateTotalCost() {
        int totalCost = 0;
        for (int i = 0; i < selectedItems.size(); i++) {
            Items item = selectedItems.get(i);
            int quantity = selectedQuantities.get(i);
            totalCost += item.getItemPrice() * quantity;
        }
        return totalCost;
    }
    /**
     * 
     * @param payment
     * @param amount 
     */
    public void initiatePayment(Payment payment, int amount) {
        payment.makePayment(amount);
    }
    public void printReceipt() {
        System.out.println("*************** Items Receipt ***************");
        for (int i = 0; i < selectedItems.size(); i++) {
            Items item = selectedItems.get(i);
            int quantity = selectedQuantities.get(i);
            System.out.println("Item: " + item.getItemName() + "\t\tQuantity: " + quantity + "\t\tPrice: " + item.getItemPrice());
        }
        int totalCost = calculateTotalCost();
        System.out.println("\nTotal Cost:  $" + totalCost);
        System.out.println("*************** End of Receipt ***************");
    }
}