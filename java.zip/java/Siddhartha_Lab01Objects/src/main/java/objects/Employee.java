/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class Employee {
    private String employeeName;
    private long empID;
    private String companyName;
    private double salary;
    private boolean isPermanent;
    private String location;
    public Employee(String employeeNameIn,long empIDIn,String companyNameIn,double salaryIn,boolean isPermanentIn,String locationIn)
    {
        employeeName = employeeNameIn;
        empID = empIDIn;
        companyName = companyNameIn;
        salary = salaryIn;
        isPermanent = isPermanentIn;
        location = locationIn;
    }
    public Employee()
    {
        System.out.println("Invoked no-argument constructor");
    }
    public String getemployeeName()
    {
        return employeeName;
    }
    public void setemployeeName(String employeeNameIn)
    {
        this.employeeName=employeeNameIn;
    }
    public long getempID()
    {
        return empID;
    }
    public void setempID(long empIDIn)
    {
        this.empID=empIDIn;
    }
    public String getcompanyName()
    {
        return companyName;
    }
    public void setcompanyName(String companyNameIn)
    {
        this.companyName=companyNameIn;
    }
    public double getsalary()
    {
        return salary;
    }
    public void setsalary(double salaryIn)
    {
        this.salary=salaryIn;
    }
    public boolean getisPermanent()
    {
        return isPermanent;
    }
    public void setisPermanent(boolean isPermanentIn)
    {
        this.isPermanent=isPermanentIn;
    }
    public String getlocation()
    {
        return location;
    }
    public void setlocation(String locationIn)
    {
        this.location=locationIn;
    }
    @Override
    public String toString()
    {
        return String.format("\n Name of the employee: %s\n EmployeeID: %d\n Name of the company: %s\n Annual salary of the employee: $%.1f\n Is employee permanent: %b\n Location of the company %s",employeeName,empID,companyName,salary,isPermanent,location);
    }
    
    
}
