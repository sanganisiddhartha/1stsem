/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public class OrdersDriver {
    /**
     * 
     * @param args
     * @throws FileNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("input.txt"));
        System.out.println("*****************************************************");
        System.out.println("******************** SHOPPING MART ******************");
        System.out.println("*****************************************************");
        while (scan.hasNextLine()) {
            //constructor
            OrdersSummary orderSum = new OrdersSummary();
            //Reading the values from the input file
            String vegetableName = scan.nextLine();
            Vegetables vegetable = Vegetables.valueOf(vegetableName.toUpperCase());
            String[] vegetableDetails = scan.nextLine().split(" ");
            int weight = Integer.parseInt(vegetableDetails[0]);
            int quantity = Integer.parseInt(vegetableDetails[1]);
            String fruitName = scan.nextLine().toUpperCase().replace(" ", "_");
            Fruit fruits = Fruit.valueOf(fruitName);
            String[] drinkDetails = scan.nextLine().split(" - ");
            String drinkName = drinkDetails[0].toUpperCase().replace(" ", "_");
            String drinkSize = drinkDetails[1];
            Drinks drinks = Drinks.valueOf(drinkName.toUpperCase());
            String milkshakeName = scan.nextLine().toUpperCase().replace(" ", "_");
            Milkshakes milkshakes = Milkshakes.valueOf(milkshakeName);
            String[] iceCreamDetails = scan.nextLine().split(" - ");
            String iceCreamName = iceCreamDetails[0].toUpperCase().replace(" ", "_");
            String iceCreamSize = iceCreamDetails[1];
            IceCreams iceCreams = IceCreams.valueOf(iceCreamName);
            String desertName = scan.nextLine().toUpperCase().replace(" ", "_");
            Desserts desert = Desserts.valueOf(desertName);
            String day = scan.nextLine();
            //constructor
            Orders order = new Orders(vegetable, weight, quantity, fruits, drinks, drinkSize, milkshakes, iceCreams, iceCreamSize, desert, day);
            orderSum.addAOrder(order);
            System.out.println(orderSum.printReceipt());
        }
        scan.close();
    }
    

}
