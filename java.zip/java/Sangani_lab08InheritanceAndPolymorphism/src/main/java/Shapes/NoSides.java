/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class NoSides extends Shapes {
    //constructor
    
    public NoSides() {
        super("NoSides");
    }
    /**
     * 
     * @return 0.0
     */
    @Override
    public double getArea() {
        return 0.0; 
    }
    @Override
    public double getPerimeter() {
        return 0.0; 
    }
    @Override
    public String toString() {
        return "      Shape : NoSides\n" +
               "      Area = " + getArea() + "cm2\n" +
               "      Perimeter = " + getPerimeter() + "cms";
    }

   
}

