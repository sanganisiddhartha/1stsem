/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class EmployeeDriver {
    public static void main(String[] args)
    {
    Employee employee1 = new Employee();
    System.out.println("***Calling toString () on employee1 object***");
    System.out.println(employee1.toString());
    employee1.setemployeeName("Jhon Doe");
    employee1.setempID(8105871);
    employee1.setcompanyName("Servicenow");
    employee1.setsalary(120000.0);
    employee1.setisPermanent(true);
    employee1.setlocation("Atlanta");
    System.out.println("***Calling toString () on employee1 object after setting values***");
    System.out.println(employee1.toString());
    System.out.println("***Testing getter method on employee1***");
    System.out.println("Name of the employee: "+employee1.getemployeeName());
    System.out.println("EmployeeID: "+employee1.getempID());
    System.out.println("Name of the company: "+employee1.getcompanyName());
    System.out.println("Anuual salary of the emloyee: $"+employee1.getsalary());
    System.out.println("Is Employee permanent: "+employee1.getisPermanent());
    System.out.println("Location of the company: "+employee1.getlocation());
    Employee employee2 = new Employee("Lokesh",231233,"Meta",150000,false,"California");
    System.out.println("***Testing toString () method on employee2***");
    System.out.println(employee2.toString());
    System.out.println("***Testing getter method on employee2***");
    System.out.println("Name of the employee: "+employee2.getemployeeName());
    System.out.println("EmployeeID: "+employee2.getempID());
    System.out.println("Name of the company: "+employee2.getcompanyName());
    System.out.println("Anuual salary of the emloyee: $"+employee2.getsalary());
    System.out.println("Is Employee permanent: "+employee2.getisPermanent());
    System.out.println("Location of the company: "+employee2.getlocation());
    System.out.println("we can create new objects often with parameters specifying the initial state or other important information about the object.");
    }
    
    
}
