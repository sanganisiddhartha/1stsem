/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public enum Fruit {
    BANANA(1.73),
    APPLES(9.78),
    GREEN_APPLES(4.83),
    ORANGES(6.68),
    PEAR(4.97),
    KIWI(4.48),
    DRAGON_FRUIT(5.98),
    PEACH(4.88);
    
    // declaring the private variable
    private final double fruitPrice;
    /**
     * 
     * @param fruitPrice 
     */
    // constructor
    private Fruit(double fruitPrice) {
        this.fruitPrice = fruitPrice;
    }
    
    // writing the getter method
    public double getFruitPrice() {
        return fruitPrice;
    }
    
}
