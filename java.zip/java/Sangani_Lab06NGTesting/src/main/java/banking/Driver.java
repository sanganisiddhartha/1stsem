/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking;
/**
* Class: 44542-NN Object-Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/01/23
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate;
public class Driver{

    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Account> accounts = new ArrayList<>();
        Scanner scanner = new Scanner(new File("input.txt"));
        scanner.nextLine();
        while (scanner.hasNextLine()) {
            String[] name = scanner.nextLine().trim().split(" ");
            String fName = name[0];
            String lName = name[1];
            String dob = scanner.nextLine().trim();
            double inc = Double.parseDouble(scanner.nextLine().trim());
            long accNum = Long.parseLong(scanner.nextLine().trim());
            double iBalance = Double.parseDouble(scanner.nextLine().trim());
            Customer customer = new Customer(dob, fName, lName, inc);
            Account acc = new Account(accNum, customer, iBalance);
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + fName + " " + lName);
            System.out.println("------------------------------------------------------------");
            while(scanner.hasNextLine()){ 
            String str=scanner.nextLine();
            
            if(str.equalsIgnoreCase("newAccount")){
                break;
            }
            else{
                String[] loanInfo = str.trim().split(" ");
                 String loanType = loanInfo[0];
                    LocalDateTime loanSanctionTime = LocalDateTime.parse(loanInfo[1] + " " + loanInfo[2], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    double loanAmount = Double.parseDouble(loanInfo[3]);
                    int noOfEMIs = Integer.parseInt(loanInfo[4]);

                    Loan loan = new Loan(loanType, loanAmount, noOfEMIs, loanSanctionTime);

                    String result = acc.applyLoan(loan);

                    if (result.equals("loan sanctioned")) {
                        System.out.println("The " + loanType + " loan status was a success with loan sanctioned for the amount of $" + loanAmount + " with a " + loan.getInterestRate() + "% Interest rate and " + noOfEMIs + "-month EMI");
                    } else {
                        System.out.println("The " + loanType + " loan status was a " + result + " for the amount of $" + loanAmount + " with a " + loan.getInterestRate() + "% Interest rate and " + noOfEMIs + "-month EMI");
                    }
            }
            }
            accounts.add(acc);  
        }
        System.out.println("************************");
        System.out.println("****Invoke emiPayment() on Account objects***");
        System.out.println("************************");
       for (Account account : accounts) {
       double emiPayment = account.emiAmount(account.getLoans());
       System.out.println(account.getCustomer().getFirstName() + " has an EMI payment of $" + String.format("%.2f", emiPayment) + " per month.");
     }
        System.out.println("************************");
        System.out.println("*************************");
        System.out.println("*Invoke generateStatement() on all objects in accounts ArrayList*");
        System.out.println("************************");
        for (Account account : accounts) {
            System.out.println(account.generateStatement());
            System.out.println("************************");
        }
    }
}