/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rentals;

/**
 *
 * @author S569434
 */

import java.util.Scanner;
/**
*
* @author S528372
*/
public class enumtype {
 
  public enum AgeCategory {
        Infant(0, 2, 30.0),
        Child(3, 12, 50.0),
        Teenager(13, 19, 65.0),
        Adult(20, 65, 70.0),
        Senior(66, Integer.MAX_VALUE, 65.0);
 
        private final int lowAge;
        private final int highAge;
        private final double heightValues;
 
        // Constructor
        AgeCategory(int minAge, int highAge, double heightValues) {
            this.lowAge = minAge;
            this.highAge = highAge;
            this.heightValues = heightValues;
        }
 
        
        public int getLowAge() {
            return lowAge;
        }
 
        public int getHighAge() {
            return highAge;
        }
 
        public double getHeightValues() {
            return heightValues;
        }
    }
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        
        int age = -1;
        while (age < 0) {
            System.out.print("Enter a person's age: ");
            if (sc.hasNextInt()) {
                age = sc.nextInt();
                if (age < 0) {
                    System.out.println("Age cannot be negative. Please enter a non-negative integer.");
                }
            } else {
                System.out.println("Invalid input. Please enter a non-negative integer.");
                sc.next(); 
            }
        }
 
       
        AgeCategory cato= categorizeAge(age);
 
        
        System.out.println("Age Category: " + cato.name());
        System.out.println("Average Height Value: " + cato.getHeightValues() + " cm");
 
        sc.close();
    }
 
    
    public static AgeCategory categorizeAge(int age) {
        for (AgeCategory category : AgeCategory.values()) {
            if (age >= category.getLowAge() && age <= category.getHighAge()) {
                return category;
            }
        }
        return null; 
    }
}