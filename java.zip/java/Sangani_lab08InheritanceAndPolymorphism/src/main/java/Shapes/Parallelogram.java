/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shapes;

import java.text.DecimalFormat;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 03/21/23
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Parallelogram extends Quadrilateral {
    /**
     * 
     * @param parallelogram
     * @param length
     * @param breadth
     * @param height 
     */
    //constructor 
    public Parallelogram(String parallelogram, int length, int breadth, int height) {
        super(length, breadth, height);
    }
    //getter methods
    public double getArea() {
        return getLength() * getHeight();
    }
    public double getPerimeter() {
        return 2 * (getLength() + getBreadth());
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Shape: Parallelogram\n");
        sb.append("      Length = ").append(getLength()).append("cm\n");
        sb.append("      Breadth = ").append(getBreadth()).append("cm\n");
        sb.append("      Height = ").append(getHeight()).append("cm\n");
        sb.append("      Area = ").append(getArea()).append("cm2\n");
        sb.append("      Perimeter = ").append(getPerimeter()).append("cms\n");
        return sb.toString();
    }
}
//    private void setName(String parallelogram) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//    

