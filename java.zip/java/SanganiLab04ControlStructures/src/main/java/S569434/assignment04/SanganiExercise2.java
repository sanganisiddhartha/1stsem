/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package S569434.assignment04;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author  Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 02/15/24
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class SanganiExercise2 {
    /**
     * 
     * @param inputNumber
     * @return 
     */
    public boolean isPerfectCube(int inputNumber)
    {
        //boolean isPerfectCube = false;
        int cbrt = (int) Math.cbrt(inputNumber);
        return cbrt * cbrt * cbrt == inputNumber;
            
        
        
        
    }
    /**
     * 
     * @param num
     * @return 
     */
    
   public boolean isPrime(int inputNumber)
            {
            boolean isItPrime = true;
            if(inputNumber <= 1)
            {
            isItPrime = false;
            return isItPrime;
            }
            else
            {
            for (int i = 2; i<= inputNumber/2; i++)
            {
            if ((inputNumber % i) == 0)
            {
            isItPrime = false;
            break;
            }
            }
            return isItPrime;
            }
            }
    /**
     * 
     * @param num
     * @return 
     */
        public static boolean isSmithNumber(int num) {
        int orgNum = num;
        int primeFacSum = 0;

        for (int i = 2; i <=num / 2; i++) {
            while (num % i == 0) {
                primeFacSum += sumOfDigits(i);
                num /= i;
            }
        }

        if (num > 1) {
            primeFacSum += sumOfDigits(num);
        }

        return sumOfDigits(orgNum) == primeFacSum;
        }


        private static int sumOfDigits(int n) {
        int sum = 0;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        return sum;
        }
        /**
         * 
         * @param num
         * @return 
         */

        public boolean isArmstrong(int num)
        {
            boolean isArmstrong;
            int temp = num,temp1 = num;
            //num=temp;
            //num=temp1;
            int count = 0;
            int sum=0;
            while(temp!=0)
            {
                temp/=10;
                count+=1;
                
            }
            //System.out.println("count"+count);
            while(temp1!=0)
            {
                int r=temp1%10;
                sum+=Math.pow(r, count);
                temp1/=10;
                //System.out.println("sum"+sum);
            }
            //System.out.println("num sum"+num+sum);
               
            if(num==sum)
            {
                isArmstrong=true;
            }
            else
            {
                isArmstrong=false;
            }
            
            
            return isArmstrong;
        }
    
            
    
}
