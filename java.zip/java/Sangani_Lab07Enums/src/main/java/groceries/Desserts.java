/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public enum Desserts {
    STRAWBERRY_CHEESECAKE(2.98),
    SWEET_POTATO_PIE(4.98),
    ORANGE_ROLLS(3.68),
    OERO_COOKIES(4.58),
    BLUEBERRY_MUFFINS(4.12),
    CREME_WAFERS(3.52),
    VANILLA_SLICED_CAKE(5.98),
    CAKE_ROLLS(4.48),
    VANILLA_CAKE_POPS(3.44);
    
    private final double dessertPrice;

    // Constructor 
    Desserts(double dessertPrice) {
        this.dessertPrice = dessertPrice;
    }

    // Getter method 
    public double getDessertPrice() {
        return dessertPrice;
    }
}
