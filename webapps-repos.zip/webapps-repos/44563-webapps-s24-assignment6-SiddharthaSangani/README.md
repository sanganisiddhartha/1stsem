[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/1Z6dGCon)
# WebApps-S24-Assignment-6
Introduction to Java Script and DOM
Animal.html page - https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment6-SiddharthaSangani/animal.html <br>
Discount.html page - https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment6-SiddharthaSangani/discount.html <br>
Packing.html page - https://44-563-web-apps-s24.github.io/44563-webapps-s24-assignment6-SiddharthaSangani/packing.html <br>
