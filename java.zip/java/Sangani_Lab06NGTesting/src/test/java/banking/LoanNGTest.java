/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package banking;

import banking.Loan;

import static org.testng.Assert.*;
import org.testng.annotations.Test;
import java.time.LocalDateTime;


public class LoanNGTest {
 
    @Test
    public void testGetInterestRate() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);
        loan.setInterestRate(6); // Set interest rate to 6%

        // Test getInterestRate() method
        assertEquals(loan.getInterestRate(), 6.0);
    }

    @Test
    public void testSetInterestRate() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);

        // Test setInterestRate() method
        loan.setInterestRate(20); // Set interest rate to 20%
        assertEquals(loan.getInterestRate(), 20.0);
    }

    @Test
    public void testGetStatus() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);
        loan.setStatus("Success");

        // Test getStatus() method
        assertEquals(loan.getStatus(), "Success");
    }

    @Test
    public void testSetStatus() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);

        // Test setStatus() method
        loan.setStatus("Failed");
        assertEquals(loan.getStatus(), "Failed");
    }

    @Test
    public void testGetLoanSanctionTime() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);

        // Test getLoanSanctionTime() method
        assertEquals(loan.getLoanSanctionTime(), loanSanctionTime);
    }

    @Test
    public void testSetLoanSanctionTime() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);
        LocalDateTime newLoanSanctionTime = LocalDateTime.of(2022, 6, 12, 2, 50); 

        // Test setLoanSanctionTime() method
        loan.setLoanSanctionTime(newLoanSanctionTime);
        assertEquals(loan.getLoanSanctionTime(), newLoanSanctionTime);
    }
 
    @Test
    public void testGetLoanAmount() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 6, loanSanctionTime);

        // Test getLoanAmount() method
        assertEquals(loan.getLoanAmount(), 60000.0);
    }

    @Test
    public void testSetLoanAmount() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 5, loanSanctionTime);

        // Test setLoanAmount() method
        loan.setLoanAmount(60000);
        assertEquals(loan.getLoanAmount(), 60000.0);
    }

    @Test
    public void testGetNoOfEMIs() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 5, loanSanctionTime);

        // Test getNoOfEMIs() method
        assertEquals(loan.getNoOfEMIs(), 5);
    }

    @Test
    public void testSetNoOfEMIs() {
        // Create a Loan instance
        LocalDateTime loanSanctionTime = LocalDateTime.now();
        Loan loan = new Loan("House", 60000, 5, loanSanctionTime);

        // Test setNoOfEMIs() method
        loan.setNoOfEMIs(6);
        assertEquals(loan.getNoOfEMIs(), 6);
    }
}