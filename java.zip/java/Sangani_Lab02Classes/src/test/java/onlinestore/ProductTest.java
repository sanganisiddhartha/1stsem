/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package onlinestore;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author S569434
 */
public class ProductTest {
    
    public ProductTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getproducrtName method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetproducrtName() {
        System.out.println("getproducrtName");
        Produc instance = new Produc();
        String expResult = "";
        String result = instance.getproducrtName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setproductName method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testSetproductName() {
        System.out.println("setproductName");
        String productNameIn = "";
        Produc instance = new Produc();
        instance.setproductName(productNameIn);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getprice method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetprice() {
        System.out.println("getprice");
        Produc instance = new Produc();
        double expResult = 0.0;
        double result = instance.getprice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setprice method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testSetprice() {
        System.out.println("setprice");
        double priceIn = 0.0;
        Produc instance = new Produc();
        instance.setprice(priceIn);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getquantity method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetquantity() {
        System.out.println("getquantity");
        Produc instance = new Produc();
        int expResult = 0;
        int result = instance.getquantity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setquantity method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testSetquantity() {
        System.out.println("setquantity");
        int quantityIn = 0;
        Produc instance = new Produc();
        instance.setquantity(quantityIn);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of gettaxPercentage method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGettaxPercentage() {
        System.out.println("gettaxPercentage");
        Produc instance = new Produc();
        double expResult = 0.0;
        double result = instance.gettaxPercentage();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of settaxPercentage method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testSettaxPercentage() {
        System.out.println("settaxPercentage");
        double taxPercentageIn = 0.0;
        Produc instance = new Produc();
        instance.settaxPercentage(taxPercentageIn);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getshippingCost method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetshippingCost() {
        System.out.println("getshippingCost");
        Produc instance = new Produc();
        double expResult = 0.0;
        double result = instance.getshippingCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setshippingCost method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testSetshippingCost() {
        System.out.println("setshippingCost");
        double shippingCostIn = 0.0;
        Produc instance = new Produc();
        instance.setshippingCost(shippingCostIn);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getcalcProductTotalPrice method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetcalcProductTotalPrice() {
        System.out.println("getcalcProductTotalPrice");
        Produc instance = new Produc();
        double expResult = 0.0;
        double result = instance.getcalcProductTotalPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getcalcProductFinalPrice method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testGetcalcProductFinalPrice() {
        System.out.println("getcalcProductFinalPrice");
        Produc instance = new Produc();
        double expResult = 0.0;
        double result = instance.getcalcProductFinalPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Product.
     */
    @org.junit.jupiter.api.Test
    public void testToString() {
        System.out.println("toString");
        Produc instance = new Produc();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
