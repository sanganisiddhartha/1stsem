https://s24wb34sangani.onrender.com
Class: DogCookies
Attributes: cookies_type(string),cookies_for(string),cost(num)