package edu.nwmissouri.S569434.arrayandarraylists;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 02/25/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
*/


public class ArrayArrayListDriver {
    /**
     * 
     * @param args
     * @throws FileNotFoundException 
     */

    public static void main(String[] args) throws FileNotFoundException {
        // Loading arrays from files
        //int[] employeeAges = loadIntArrayFromFile("employeeAges.txt", 6);
        Scanner S = new Scanner(new File("employeeAges.txt"));
        Scanner SS = new Scanner(new File("employeeNames.txt"));
    
        int[] employeeAges = new int[6];
        
        while (S.hasNext()) {
            for (int i = 0; i < 6; i++) {
               employeeAges [i] = S.nextInt();
            }
        }
        //String[] employeeNames = loadStringArrayFromFile("employeeNames.txt", 7);
        String[] employeeNames = new String[7];
        while (SS.hasNext()) {
            for (int i = 0; i < 7; i++) {
                employeeNames[i] = SS.nextLine();
            }
        }
        // Invoking array operations
        ArrayOps.arrayOperations(employeeAges, employeeNames);

        // Loading ArrayLists from files
        ArrayList<Integer> numbersArrayList = loadIntegerArrayListFromFile("numbers.txt");
        ArrayList<String> quotesArrayList = loadStringArrayListFromFile("qoutes.txt");
        ArrayList<Double> salariesArrayList = loadDoubleArrayListFromFile("salaries.txt");

        // Invoking ArrayList operations
        ArrayListOps.arrayListOperations(numbersArrayList, quotesArrayList, salariesArrayList);
    }

    // Load integer array from file
    /**
     * 
     * @param fileName
     * @param size
     * @return
     * @throws FileNotFoundException 
     */
    public static int[] loadIntArrayFromFile(String fileName, int size) throws FileNotFoundException {
        int[] array = new int[size];
        try (Scanner scanner = new Scanner(new File(fileName))) {
            for (int i = 0; i < size && scanner.hasNextInt(); i++) {
                array[i] = scanner.nextInt();
            }
        }
        return array;
    }

    // Load string array from file
    /**
     * 
     * @param fileName
     * @param size
     * @return
     * @throws FileNotFoundException 
     */
    public static String[] loadStringArrayFromFile(String fileName, int size) throws FileNotFoundException {
        String[] array = new String[size];
        try (Scanner scanner = new Scanner(new File(fileName))) {
            for (int i = 0; i < size && scanner.hasNextLine(); i++) {
                array[i] = scanner.nextLine();
            }
        }
        return array;
    }

    // Load ArrayList<Integer> from file
    /**
     * 
     * @param fileName
     * @return
     * @throws FileNotFoundException 
     */
    public static ArrayList<Integer> loadIntegerArrayListFromFile(String fileName) throws FileNotFoundException {
        ArrayList<Integer> list = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextInt()) {
                list.add(scanner.nextInt());
            }
        }
        return list;
    }

    // Load ArrayList<String> from file
    /**
     * 
     * @param fileName
     * @return
     * @throws FileNotFoundException 
     */
    public static ArrayList<String> loadStringArrayListFromFile(String fileName) throws FileNotFoundException {
        ArrayList<String> list = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                list.add(scanner.nextLine());
            }
        }
        return list;
    }

    // Load ArrayList<Double> from file
    /**
     * 
     * @param fileName
     * @return
     * @throws FileNotFoundException 
     */
    public static ArrayList<Double> loadDoubleArrayListFromFile(String fileName) throws FileNotFoundException {
        ArrayList<Double> list = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextDouble()) {
                list.add(scanner.nextDouble());
            }
        }
        return list;
    }
}
