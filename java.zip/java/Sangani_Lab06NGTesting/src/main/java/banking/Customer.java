/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package banking;

import java.time.LocalDate;

/**
* Class: 44542-NN Object-Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/01/23
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public class Customer {

    private String dob;
    private String firstName;
    private String  lastName;
    private double income;
    
    /**
     * 
     * @param dob
     * @param firstName
     * @param lastName
     * @param income 
     */
    public Customer(String dob, String firstName, String lastName, double income) {
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
        this.income = income;
    }

    
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    
    @Override
    public String toString() {
        return "Name: " + lastName + ", " + firstName + "\n" +
                "Date of Birth: " + dob + "\n" +
                "Income: " + income;
    }
}