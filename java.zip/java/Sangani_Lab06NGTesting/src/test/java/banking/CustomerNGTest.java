/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package banking;


/**
 *
 * @author S569434
 */


import org.testng.Assert;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class CustomerNGTest {

    @Test
    public void testCustomerConstructor() {
        // Create a Customer instance
        Customer customer = new Customer("06/12/2002", "Sid", "San", 90000);

        // Verify the constructor sets the fields correctly
        Assert.assertEquals(customer.getDob(), "06/12/2002");
        Assert.assertEquals(customer.getFirstName(), "Sid");
        Assert.assertEquals(customer.getLastName(), "San");
        Assert.assertEquals(customer.getIncome(), 90000.0);
    }

    @Test
    public void testGettersAndSetters() {
        // Create a Customer instance
        Customer customer = new Customer("06/12/2002", "sid", "san", 90000);

        // Test the getter and setter methods
        customer.setDob("06/12/2002");
        Assert.assertEquals(customer.getDob(), "06/12/2002");

        customer.setFirstName("sid");
        Assert.assertEquals(customer.getFirstName(), "sid");

        customer.setLastName("san");
        Assert.assertEquals(customer.getLastName(), "san");

        customer.setIncome(90000);
        Assert.assertEquals(customer.getIncome(), 90000.0);
    }

    @Test
    public void testToString() {
        // Create a Customer instance
        Customer customer = new Customer("06/12/2002", "sid", "san", 90000);

        // Test the toString() method
        String expectedToString = "Name: san, sid\nDate of Birth: 06/12/2002\nIncome: 90000.0";
        Assert.assertEquals(customer.toString(), expectedToString);
    }
}