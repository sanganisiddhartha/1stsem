/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package S569434.assignment04;

import java.util.Random;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author  Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 02/15/24
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */

public class SiddharthaSecretCode {
    /**
     * 
     * @return 
     */
    public int pickRandomCard(){
        Random sec = new Random();
        return sec.nextInt(13);
    }
    /**
     * 
     * @param number
     * @return 
     */
    public boolean isPerfectSquare(int number){
        int sqrt = (int) Math.sqrt(number);
        return sqrt * sqrt == number;
    }
    /**
     * 
     * @param card1
     * @param card2
     * @param card3
     * @return 
     */
    public int sumOfCards(int card1, int card2, int card3) {
        return card1 + card2 + card3;
    }
/**
 * 
 * @param number
 * @return 
 */
   
    public boolean isFibonacci(int number) {
        int a = 0, b = 1;
        while (b < number) {
            int temp = b;
            b = a + b;
            a = temp;
        }
        return b == number;
    }
    
    
}
