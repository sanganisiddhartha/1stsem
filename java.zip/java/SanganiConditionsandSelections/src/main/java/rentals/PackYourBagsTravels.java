/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rentals;

/**
* Class: 44542-04 Object Oriented Programming
* @author SIddhartha Sangani
* Description: Making sure everything works
* Due: 02/08/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public class PackYourBagsTravels {
    private String destination;
    private int numOfPassengers;
    private String flightClass;
    private double TAX_FlIGHT=0.05;
    private double TAX_HOTEL=0.10;
    private double TAX_CAR_RENTAL=0.03;
    private boolean isMember;
    private boolean isFirstMember;
    private String hotelType;
    private int numOfNights;
    private String customerName;
    private String carType;
    private int rentalDays;
 
   
   public PackYourBagsTravels(String destination, int numOfPassengers, String flightClass, boolean isMember, boolean isFirstMember) 
   {
       this.destination=destination;
       this.numOfPassengers=numOfPassengers;
       this.flightClass=flightClass;
       this.isMember=isMember;
       this.isFirstMember=isFirstMember;
   
   }
   /**
    * 
    * @param hotelType
    * @param numOfNights
    * @param customerName 
    */
   public PackYourBagsTravels (String hotelType, int numOfNights, String customerName)
   {
       this.hotelType=hotelType;
       this.numOfNights=numOfNights;
       this.customerName=customerName;
   }
   /**
    * 
    * @param customerName
    * @param carType
    * @param rentalDays 
    */
   public PackYourBagsTravels(String customerName, String carType, int rentalDays)
   {
       customerName=customerName;
       carType=carType;
       rentalDays=rentalDays;
   }
   /**
    * 
    * 
    * @return 
    */
    public String getdestination()
    {
        return destination;
    }
    /**
     * 
     * @param destinationIn 
     */
    public void setdestination(String destinationIn)
    {
        this.destination= destinationIn;
    }
    /**
     * 
     * @return 
     */
    public int getnumOfPassengers()
    {
        return numOfPassengers;
    }
    /**
     * 
     * @param numOfPassengersIn 
     */
    public void setnumOfPassengers(int numOfPassengersIn)
    {
        this.numOfPassengers= numOfPassengersIn;
    }
    /**
     * 
     * @return 
     */
    public String getflightClass()
    {
        return flightClass;
    }
    /**
     * 
     * @param flightClassIn 
     */
    public void setflightClass(String flightClassIn)
    {
        this.flightClass= flightClassIn;
    }
    /**
     * 
     * @return 
     */
    public boolean getisMember()
    {
        return isMember;
    }
    /**
     * 
     * @param isMemberIn 
     */
    public void setisMember(boolean isMemberIn)
    {
        this.isMember=isMemberIn;
   
    }
    /**
     * 
     * @return 
     */
    public boolean getisFirstMember()
    {
        return isFirstMember;
    }
    /**
     * 
     * @param isFirstMemberIn 
     */
    public void setisFirstMember(boolean isFirstMemberIn)
    {
        this.isFirstMember=isFirstMemberIn;
    }
    /**
     * 
     * @return 
     */
    public String gethotelType()
    {
        return hotelType;
    }
    /**
     * 
     * @param hotelType 
     */
    public void sethotelType(String hotelType)
    {
        this.hotelType=hotelType;
    }
    /**
     * 
     * @return 
     */
    public int getnumOfNights()
    {
        return numOfNights;
    }
    /**
     * 
     * @param numOfNights 
     */
    public void setnumOfNights(int numOfNights)
    {
        this.numOfNights= numOfNights;
    }
    /**
     * 
     * @return 
     */
    public String getcoustomerName()
    {
        return customerName;
    }
    /**
     * 
     * @param customerName 
     */
    public void setcustomerName(String customerName)
    {
        this.customerName=customerName;
    }
    /**
     * 
     * @return 
     */
    public String getcarType()
    {
        return carType;
    }
    /**
     * 
     * @param carType 
     */
    public void setcarType(String carType)
    {
        this.carType=carType;
    }
    /**
     * 
     * @return 
     */
    public int getrentalDays()
    {
        return rentalDays;
    }
    /**
     * 
     * @param rentalDays 
     */
    public void setrentalDays(int rentalDays)
    {
        this.rentalDays=rentalDays;
    }
    /**
     * 
     * @return 
     */
    public double checkMemberShip() {
        double discount = 0.0;
        if (isMember && !isFirstMember) {
            discount = 0.30;
        } else if (isMember && isFirstMember) {
            discount = 0.15;
        }
        return discount;
    }
    /**
     * 
     * @return 
     */
    public double checkFlightFare()
    {
        double fare;
        if("First Class".equals(flightClass))
        {
            fare=3000.0;
        }
        else if("Business".equals(flightClass))
        {
            fare=2500.0;
        }
        else if("Premium Economy".equals(flightClass))
        {
            fare=2000.0;
        }
        else
        {
            fare=1500.0;
        }
        return fare;
    }
    /**
     * 
     * @return 
     */
    public double totalFlightCost()
    {
        double discount = checkMemberShip();
        double fare = checkFlightFare() * numOfPassengers;
       
        double taxAmount = fare * TAX_FlIGHT;
        double totalCost = fare + taxAmount;
        double discountedAmount = totalCost * discount;
        return totalCost - discountedAmount;
    }
    /**
     * 
     * @param hotelType
     * @param numOfNights
     * @return 
     */
    public double hotelCost(String hotelType,int numOfNights)
    {
        double hotelCost;
        if("OneStar".equals(hotelType))
        {
            hotelCost = 100;
        }
        else if("TwoStar".equals(hotelType))
        {
            hotelCost = 121.32;
        }
        else if("ThreeStar".equals(hotelType))
        {
            hotelCost = 142.23;
        }
        else if("FourStar".equals(hotelType))
        {
            hotelCost = 170.78;
        }
        else
        {
            hotelCost = 200;
        }
        return hotelCost;
    }
    /**
     * 
     * @param hotelType
     * @param numOfNights
     * @return 
     */
    public double totalHotelCost(String hotelType, int numOfNights)
    {
        double totalhotelCost = hotelCost(hotelType, numOfNights)*numOfNights;
        return totalhotelCost + (totalhotelCost * TAX_HOTEL);
    }
    /**
     * 
     * @param destination1
     * @param flightClass1
     * @param numOfPassengers1
     * @param member
     * @param firstMember
     * @return 
     */
    public String flightTktPrint( String destination1, String flightClass1, int numOfPassengers1, boolean member, boolean firstMember)
    {
       return "***************************************************\n"+
               "***       PACK YOUR BAGS                     ******\n"+
               "***************************************************\n"
               +"*Date:02/03/2024                         Time:8:09*\n"+
               "**********FLIGHT TICKET DETAILS********************\n"+
                "*Airline : Air India                     Gate : 33*\n"
                +"* Destination: "+getdestination()+"\n"+
               "* CLASS:"+getflightClass()+"("+checkFlightFare()+")"+"\n"+
               "* Num of passengers:"+getnumOfPassengers()+"\n"+
               "*                      ------------------\n"+
               "Total Flight Cost(Inc Tasx): $" + totalFlightCost()+"\n"
               +"***************************************************\n"
               +"*---------------Happy journey---------------------*\n"
               +"*--------------Thank you visit again--------------*\n"
               +"---------------------------------------------------\n";
    }
    /**
     * 
     * @param customerName
     * @param hotelType
     * @param numOfNights
     * @return 
     */
    public String hotelTktPrint(String customerName,String hotelType, int numOfNights)
    {
        return "************************************\n"+
                "***       PACK YOUR BAGS                     ******\n"+
                "***************************************************\n"+
                "*Date:02/03/2024                         Time:8:09*\n"+
                "*                                                 *\n"+
                "*************HOTEL BOOKING BILL********************\n"+
                "* Coustomer name: "+customerName+"\n"+
                "* Hotel type:"+hotelType+"\n"+
                "* No of nights: "+numOfNights+"\n"+
                "*Cost per night: "+hotelCost(hotelType,numOfNights)+"\n"+
                "*                      ------------------\n"+
                "Total hotel booking cost(Inc tax)"+totalHotelCost(hotelType, numOfNights)+"\n"+
                "*                      ------------------\n"+
                "---------HAVE A GREAT STAY---------------\n"+
                "-----------------------------------------------";
    }
    /**
     * 
     * @param carType
     * @return 
     */
    public double carRent(String carType)
    {
        double carRent = 50;
        if("economy".equals(carType))
        {
            carRent=50;
        }
        else if("compact".equals(carType))
        {
            carRent=75;
        }
        else if("premium".equals(carType))
        {
            carRent=100;
        }
        else if("suv".equals(carType))
        {
            carRent=150;
        }
        return carRent;
    }
    /**
     * 
     * @param carType
     * @param rentDays
     * @return 
     */
    public double carTotalRent(String carType, int rentDays)
    {
        double carRent = carRent(carType);
        return (carRent * rentDays) + ((carRent * rentDays) * TAX_CAR_RENTAL);
    }
    /**
     * 
     * @param customerName
     * @param carType
     * @param days
     * @return 
     */
    public String carTktDetails( String customerName, String carType, int days)
    {
       return "************************************\n"+
                "***       PACK YOUR BAGS                     ******\n"+
                "***************************************************\n"+
                "*Date:02/03/2024                         Time:8:09*\n"+
                "*                                                 *\n"+
               "**************CAR RENTAL DETAILS*********************\n"+
               "Coustomer name: "+customerName+"\n"+
               "Type of car: "+carType+"\n"+
               "No of days: "+days+"\n"+
                "*                      ------------------\n"+
                "Total CAR RENT(Inc Tax):"+carTotalRent(carType,days)+"\n"+
               "*                      ------------------\n"+
                "---------Thank you for renting with us---------------\n"+
                "-----------------------------------------------";
       
    }
    
    }