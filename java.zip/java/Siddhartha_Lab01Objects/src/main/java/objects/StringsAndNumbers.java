package objects;

import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
* Class: 44542-NN Object-Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 01/18/24
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public class StringsAndNumbers {

    public static void main(String[] args) {
        String greet = "Hello Bearcats welcome to spring 2024 Object Oriented Programing class";
        String value = String.valueOf(greet);
        int length = greet.length();
        String substring = greet.substring(38, 65);
        String intro = "My name is Siddhartha_Sangani";
        String favsubject = "My favorite programming language is python because";
        String reason = "it is easy to learn and can be used to perform many functions";
        String about = String.join(".", intro, favsubject, reason);
        //String replaced = about.setCharAt(80," ");
        String language = about.substring(66, 73);
        String firstLab = "This is my first Java Lab Activity";
        String lowerLab = firstLab.toLowerCase();
        System.out.println(value);
        System.out.println("The size of the string is" + length);
        //System.out.println("Hello Bearcats welcome to spring 2024 \"\"Object Oriented Programing\"\" class");
        System.out.println(greet.replace("Object Oriented Programing", " \"\"Object Oriented Programing\"\""));
        System.out.println(substring);
        System.out.println("Starts with Hello or not? " + greet.startsWith("Hello"));
        System.out.println("End with programing or not? " + greet.endsWith("programing"));
        System.out.println(about);
        System.out.println("The second occurance of the full stop in string is at position " + about.lastIndexOf("."));
        String rAbout = about.substring(0, 80) + " " + about.substring(80 + 1);
        System.out.println("String after replacing the second occurance of fullstop with:"+rAbout);
        //System.out.println("After replacing second occurrence of \".\": " + about.replaceFirst("\\.", " "));
        System.out.println("My favlanguage name from the string is" + language);
        System.out.println(language.repeat(5));
        //System.out.println(lowerLab);
        System.out.println("By using equals()" + firstLab.equals(lowerLab));
        System.out.println("By using equalsIgnoreCase() " + firstLab.equalsIgnoreCase(lowerLab));
        System.out.println("String after replacing all occurances of charcter 'i' in firstlab with a character 'x' is" + firstLab.replaceAll("i", "x"));
        System.out.println("After trim " + firstLab.trim());
        System.out.println("rounded value of sqrt" + Math.round(Math.sqrt((Math.pow(9, 3)) + Math.pow(24, 3))));
        double result1 = (Math.cos(Math.toRadians(60)) * Math.cos(Math.toRadians(30))) + (Math.sin(Math.toRadians(60)) * Math.sin(Math.toRadians(30)));
        System.out.println("cos60cos30 +sin60sin30 is:" + result1);
        double result2 = Math.cos(Math.toRadians(60 - 30));
        System.out.println("cos(60-30) is:" + result2);
        System.out.println("Same Result");
        System.out.println("The ceil value of cos60cos30 +sin60sin30 is:" + Math.ceil(result1));
        System.out.println("log of 92 is " + Math.log(95));
        System.out.println("log of 32 is " + Math.log(32));
        int m = ((8 - 4) / (3 - 1));
        int inter = 4 - (m * 1);
        System.out.println("y=" + m + "x+" + inter);//intersection left

        int max = 500, min = 100;
        Random rand = new Random();
        int a = rand.nextInt(max - min + 1) + min;
        int x = rand.nextInt(max - min + 1) + min;
        int y = rand.nextInt(max - min + 1) + min;
        int z = rand.nextInt(max - min + 1) + min;
        System.out.println("First Random integer is: " + a + " Sqrt of " + a + " " + Math.sqrt(a));
        System.out.println("second Random integer is: " + x + " Sqrt of " + x + " " + Math.sqrt(x));
        System.out.println("Third Random integer is: " + y + " Sqrt of " + y + " " + Math.sqrt(y));
        System.out.println("Fourth Random integer is: " + z + " Sqrt of " + z + " " + Math.sqrt(z));
        int b = rand.nextInt();
        int c = rand.nextInt();
        int d = rand.nextInt();
        int f = rand.nextInt();
        System.out.println("fifth random integer value " + b);
        System.out.println("Sixth random integer value " + c);
        System.out.println("seventh randon integer value " + d);
        System.out.println("eigth random integer value " + f);
        System.out.println("after running the program for three to 4 times i am receving the different output for every time i run the program");
        long seed = 40;
        Random randomno = new Random(seed);
        int ma = 500, mi = 100;
        int r1 = randomno.nextInt(ma - mi + 1) + mi;
        int r2 = randomno.nextInt(ma - mi + 1) + mi;
        int r3 = randomno.nextInt(ma - mi + 1) + mi;
        int r4 = randomno.nextInt(ma - mi + 1) + mi;
        System.out.println("First Random number is: " + r1 + " Sqrt of " + r1 + " " + Math.sqrt(r1));
        System.out.println("second Random number is: " + r2 + " Sqrt of " + r2 + " " + Math.sqrt(r2));
        System.out.println("Third Random number is: " + r3 + " Sqrt of " + r3 + " " + Math.sqrt(r3));
        System.out.println("Fourth Random number is: " + r4 + " Sqrt of " + r4 + " " + Math.sqrt(r4));
        int r5 = randomno.nextInt();
        int r6 = randomno.nextInt();
        int r7 = randomno.nextInt();
        int r8 = randomno.nextInt();
        System.out.println("fifth random integer value is " + r5);
        System.out.println("Sixth random integer value is" + r6);
        System.out.println("seventh randon integer value is" + r7);
        System.out.println("eigth random integer value is" + r8);
        System.out.println("After executing the code 3-4 times I can see the same random numbers they arent changing");
        Random random2 = new Random();
        int maxi = 10, mini = 1;
        int radius = random2.nextInt(maxi - mini) + mini;
        //System.out.println(radius);
        System.out.println("Area of the circle with random radius "+ radius +"is " + Math.PI * Math.pow(radius, 2));
        System.out.println("Perimeter of circle with random radius " + radius +"is " + 2 * Math.PI * radius);

    }
}
