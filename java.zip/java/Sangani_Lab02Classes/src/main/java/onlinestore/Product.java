/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinestore;

/**
 * Class: 44542-NN Object Oriented Programming
* @author  Siddhartha Sangani
* Description: Making sure everything works
* Due: 01/29/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
 */
public class Product {
    private String productName;
    private double price;
    private int quantity;
    private double taxPercentage;
    private final double DISCOUNT=15;
    private double totalPrice;
    private double finalPrice;
    private double shippingCost;
    public Product (String productNameIn,double priceIn,int quantityIn, double taxPercentageIn,double shippingCostIn)
    {
        productName = productNameIn;
        price = priceIn;
        quantity = quantityIn;
        taxPercentage = taxPercentageIn;
        shippingCost = shippingCostIn;
        
    }
    
    public Product()
    {
        
    }
    /**
     * no args constructor
     * @return 
     */
    public String getproducrtName()
    {
        return productName;
    }
    /**
     * 
     * @param productNameIn 
     */
    public void setproductName(String productNameIn)
    {
        this.productName = productNameIn;
    }
    /**
     * 
     * @return 
     */
    public double getprice()
    {
        return price; 
    }
    /**
     * 
     * @param priceIn 
     */
    public void setprice(double priceIn)
    {
        this.price=priceIn;
    }
    /**
     * 
     * @return 
     */
    public int getquantity()
    {
        return quantity;
    }
    /**
     * 
     * @param quantityIn 
     */
    public void setquantity(int quantityIn)
    {
        this.quantity=quantityIn;
    }
    /**
     * 
     * @return 
     */
    public double gettaxPercentage()
    {
        return taxPercentage;
    }
    /**
     * 
     * @param taxPercentageIn 
     */
    public void settaxPercentage(double taxPercentageIn)
    {
        this.taxPercentage=taxPercentageIn;
    }
    /**
     * 
     * @return 
     */
    public double getshippingCost()
    {
        return shippingCost;
    }
    /**
     * 
     * @param shippingCostIn 
     */
    public void setshippingCost(double shippingCostIn)
    {
        this.shippingCost=shippingCostIn;
    }
    /**
     * 
     * @return 
     */
    public double getcalcProductTotalPrice()
    {
        double calcProductTotalPrice=(price+shippingCost)*quantity+((price+shippingCost)*quantity*taxPercentage/100);
        return calcProductTotalPrice;
    }
    /**
     * 
     * @return 
     */
    public double getcalcProductFinalPrice()
    {
        double calcProductFinalPrice=(price+shippingCost)*quantity-((price+shippingCost)*quantity*(DISCOUNT/100));
        return calcProductFinalPrice;
        
        
    }
    /**
     * 
     * @return 
     */
    @Override
    public String toString()
    {
        return String.format("\n Name of the Product : %s\n price of the Product: $%.1f\n Quantity : %d\n taxpercentage: %.2f%%\n Discount:%.2f \n Shipping Cost : $%.2f",productName,price,quantity,taxPercentage,DISCOUNT/100,shippingCost);
    }
    
}
