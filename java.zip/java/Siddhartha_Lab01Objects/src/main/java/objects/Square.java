/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

/**
 *
 * @author S569434
 */
public class Square {
    private double sideLength;
    /**
     * 
     * @param sideLengthIn 
     */
    public Square(double sideLengthIn){
        sideLength = sideLengthIn;
    }
   
    public Square()
    {
        sideLength=0.0;
    }
    /**
     * 
     * @return sidelength
     */
    public double getsideLength()
    {
        return sideLength;
    }
    
    /**
     * 
     * @param sideLengthIn 
     * 
     */
    public void setsideLength(double sideLengthIn)
    {
        this.sideLength=sideLengthIn;
    }
    /**
     * 
     * @return sidelength
     */
    public double getArea()
    {
        double area= sideLength*sideLength;
        return area;
    }
    /**
     * 
     * @return double area
     */
    public double getPerimeter()
    {
        double perimeter= 4*sideLength;
        return perimeter;
    }
    
}

