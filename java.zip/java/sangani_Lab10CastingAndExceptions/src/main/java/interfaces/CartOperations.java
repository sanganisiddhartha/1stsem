/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import onlineShopping.Items;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 04/05/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
public interface CartOperations {
    void displayInventoryItems(ArrayList<Items> itemsList);
    void addItemsToCart(Items item, int quantity);
    int calculateTotalCost();
    void initiatePayment(Payment payment, int amount);
    void printReceipt();
}