/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package groceries;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 03/07/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/

public enum IceCreams {
     MAPPLE_NUT(3.98, 6.23, 11.57),
    CHOCOLATE_CRYSTAL(4.15, 7.20, 13.46),
    FRENCH_VANILLA(3.45, 5.98, 10.23),
    TRIPLE_TORNADO(4.27, 6.75, 12.84),
    COOKIES_AND_CREAM(5.10, 7.29, 13.80),
    COTTON_CANDY(3.45, 5.73, 12.09),
    BUTTERSCOTCH_RIPPLE(3.18, 4.49, 9.59),
    EXPRESSO_FLAKE(2.79, 4.12, 8.94),
    BLACK_CHERRY(4.35, 6.18, 12.04);
    // declaring variables
    private final double small;
    private final double family;
    private final double party;
    /**
     * 
     * @param small
     * @param family
     * @param party 
     */
    // constructor
    private IceCreams(double small, double family, double party) {
        this.small = small;
        this.family = family;
        this.party = party;
    }
    // getter methods
    public double getSmall() {
        return small;
    }

    public double getFamily() {
        return family;
    }

    public double getParty() {
        return party;
    }
}
