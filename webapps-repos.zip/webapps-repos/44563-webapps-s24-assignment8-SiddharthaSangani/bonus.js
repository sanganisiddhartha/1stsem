const http = require('http')    //Pull in a useful node package
                                
const hostname = '127.0.0.1'    //Local host
const port = 3001              //and the port
const items = ['Shoes', 'Shirts', 'Socks', 'Shorts', 'Snacks'];
const usedItems = new Array(items.length).fill(false);

const server =
  http.createServer(            //Creates the response loop
    (req,res)=> {               //Anonymous function to handle the request
      res.statusCode = 200      //code for OK
      let randomIndex = Math.floor(Math.random() * items.length);
      while (usedItems[randomIndex]) {
            randomIndex = (randomIndex + 1) % items.length;
        }
      usedItems[randomIndex] = true;
      let responseHtml = `
    <html>
    <head>
      <title>Siddhartha's ${items[randomIndex]}</title>
    </head>
    <body>
      <h1>Siddhartha's Snacks</h1>
      <p>Index: ${randomIndex}</p>
      <p>Item: ${items[randomIndex]}</p>
    </body>
    </html>
  `;
     res.setHeader('Content-Type', 'text/html')
     res.end(responseHtml);

    //   res.write('<html> <head> <title> Siddhartha Snacks </title> </head>')
    //   res.write('<body>')
    //   res.write('<h1>Siddhartha Collection</h1>')
    //   res.write('<p>Index: ${randomIndex}</p><p>Item: ${items[randomIndex]}</p>')
      //res.write('Hello World')    
      //res.end('</body></html>')
      //Close the response
    }                           
)

server.listen(port, hostname, () => {   //Start the server
  console.log(`Server running at http://${hostname}:${port}/`)  //Log the request
})