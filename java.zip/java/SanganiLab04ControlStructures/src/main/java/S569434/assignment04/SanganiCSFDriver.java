/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package S569434.assignment04;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 * Class: 44542-04 Object Oriented Programming
 * @author  Siddhartha Sangani
 * Description: Making sure everything works
 * Due: 02/15/24
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class SanganiCSFDriver {
    public static void main(String[] args) throws FileNotFoundException
    {
        String inputString = "Object Oriented programming";
        SanganiPattern pattern = new SanganiPattern();
        pattern.printPattern(inputString);
        Scanner scr = new Scanner(new File("C:\\Users\\S569434\\Downloads\\Lab04\\Lab04\\assignment04Data.txt"));
        SanganiExercise2 file = new SanganiExercise2();
        PrintWriter primeWriter = new PrintWriter("prime.txt");
        PrintWriter  smithWriter = new PrintWriter("smith.txt");
        PrintWriter perfectCubeWriter = new PrintWriter("perfectCube.txt");
        PrintWriter armstrongWriter = new PrintWriter("armstrong.txt");
        int primeCount = 0;
        int smithCount = 0;
        int perfectCubeCount = 0;
        int armstrongCount = 0;
        while (scr.hasNext()) {
            int digit = scr.nextInt();

            
            boolean isPrime = file.isPrime(digit);
            boolean isPerfectCube = file.isPerfectCube(digit);
            boolean isArmstrong = file.isArmstrong(digit);
            boolean isSmithNumber = file.isSmithNumber(digit);

            
            if (isPrime) {
                primeWriter.println(digit);
                primeCount++;
            }
            if(isSmithNumber){
                smithWriter.println(digit);
                smithCount++;
                
            }
            if (isPerfectCube) {
                perfectCubeWriter.println(digit);
                perfectCubeCount++;
                
            }
            if (isArmstrong) {
                armstrongWriter.println(digit);
                armstrongCount++;
            }
        }
        System.out.println("Total prime numbers: " + primeCount);
        System.out.println("Total Smith numbers: " + smithCount);
        System.out.println("Total perfect cube numbers: " + perfectCubeCount);
        System.out.println("Total Armstrong numbers: " + armstrongCount);
        
        armstrongWriter.close();
        perfectCubeWriter.close();
        primeWriter.close();


        
        
        SiddharthaSecretCode ex3 = new SiddharthaSecretCode();
        int card1 = ex3.pickRandomCard();
        int card2 = ex3.pickRandomCard();
        int card3 = ex3.pickRandomCard();
        

        boolean twoFibonacci = ex3.isFibonacci(card1) && ex3.isFibonacci(card2) ||
                ex3.isFibonacci(card1) && ex3.isFibonacci(card3) ||
                ex3.isFibonacci(card2) && ex3.isFibonacci(card3);
        boolean onePerfectSquare = ex3.isPerfectSquare(card1) || ex3.isPerfectSquare(card2) || ex3.isPerfectSquare(card3);

        int sum = ex3.sumOfCards(card1, card2, card3);
        boolean sumFibonacci = ex3.isFibonacci(sum);
        
        System.out.println("The random values generated card values are:");
        System.out.println("Card1: " + card1 + "\nCard2: " + card2 + "\nCard3: " + card3);
        //System.out.println("Sum of cards: " + sum);

        if (!twoFibonacci) {
            System.out.println("Better luck next time..! Not all  card's values are part of the Fibonacci sequence.");
        } else if (!onePerfectSquare) {
            System.out.println("Better luck next time..! At least one cards's value should be a perfect square.");
        } else if (!sumFibonacci) {
            System.out.println("Better luck next time..! The sum of cards is not a Fibonacci number.");
        } else {
            System.out.println("Congratulations!.. You have successfully cracked the secret code!");
        }
    }

    
}
