/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 04/05/2024
* I pledge that I have completed the programming assignment independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share this code with
anyone under my circumstances.
*/
import exceptions.InvalidItemIdException;
import exceptions.InvalidQuantityIdException;
import interfaces.CartOperations;
import interfaces.Payment;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import onlineShopping.Items;
import onlineShopping.OnlineShoppingImpl;
import paymentImpl.CardPayment;
import paymentImpl.PayPalPayment;

public class Driver {

    private static Scanner ip = new Scanner(System.in);
    private static CartOperations co = new OnlineShoppingImpl();

    public static void main(String[] args) {
        ArrayList<Items> il = new ArrayList<>();
        readFile(il);

        co.displayInventoryItems(il);

        System.out.println("******* WELCOME To ONLINE SHOPPING *********");
        purchaseItems(il);

        System.out.println("******* Thanks for shopping! Please visit again. *********");
        co.displayInventoryItems(il);
    }

    private static void readFile(ArrayList<Items> itemsList) {
        try {
            File file = new File("input.txt");
            Scanner fip = new Scanner(file);
            while (fip.hasNextLine()) {
                String line = fip.nextLine();
                String[] parts = line.split(" ");
                int itemId = Integer.parseInt(parts[0]);
                String itemName = parts[1];
                int itemPrice = Integer.parseInt(parts[2]);
                int availableQuantity = Integer.parseInt(parts[3]);
                itemsList.add(new Items(itemId, itemName, itemPrice, availableQuantity));
            }
            fip.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: input.txt");
            e.printStackTrace();
        }
    }

    private static void purchaseItems(ArrayList<Items> itemsList) {
        String purchaseMore;
        do {
            try {
                System.out.println("Please select the item id to add to the cart:");
                int itemId = ip.nextInt();
                ip.nextLine();
                Items selected = getItemById(itemsList, itemId);

                int availableQuantity = selected.getAvailableQuantity();
                int selectedQuantity;
                do {
                    System.out.println("Please select the quantity of the itemid:" + itemId + " to purchase :");
                    selectedQuantity = ip.nextInt();
                    ip.nextLine(); 
                    if (selectedQuantity > availableQuantity) {
                        System.out.println("Please select from the available quantity which is " + availableQuantity);
                    }
                } while (selectedQuantity > availableQuantity);

                co.addItemsToCart(selected, selectedQuantity);
                 selected.setAvailableQuantity(availableQuantity - selectedQuantity);


                System.out.println("Do you want to purchase more? Y/N");
                purchaseMore = ip.nextLine();
            } catch (InvalidItemIdException e) {
                System.out.println("Please select from the available options only.");
                purchaseMore = "Y"; // Reset to continue the loop
            }
        } while (purchaseMore.equalsIgnoreCase("Y"));

        double totalCost = co.calculateTotalCost();
        System.out.println("******\nTotal cost of the purchase: $" + totalCost + "\n********");

        System.out.println("Please select the mode of payment");
        System.out.println("1. Card\n2. PayPal");
        int paymentMode;
        do {
            paymentMode = ip.nextInt();
            ip.nextLine(); 
            if (paymentMode != 1 && paymentMode != 2) {
                System.out.println("Invalid payment mode selected. Please select again.");
            }
        } while (paymentMode != 1 && paymentMode != 2);

        Payment payment;
        if (paymentMode == 1) {
            System.out.println("Please enter your Card Number:");
            String cardNumber = ip.nextLine();
            payment = new CardPayment(cardNumber);
        } else {
            System.out.println("Please enter your Email:");
            String email = ip.nextLine();
            payment = new PayPalPayment(email);
        }

        co.initiatePayment(payment, (int) totalCost);
        co.printReceipt();
    }

    private static Items getItemById(ArrayList<Items> itemsList, int itemId) throws InvalidItemIdException {
        for (Items item : itemsList) {
            if (item.getItemId() == itemId) {
                return item;
            }
        }
        throw new InvalidItemIdException("Invalid item ID entered.");
    }
}