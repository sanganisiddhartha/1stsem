/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinestore;

/**
* Class: 44542-NN Object Oriented Programming
* @author  Siddhartha Sangani
* Description: Making sure everything works
* Due: 01/29/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
 */
import java.util.*;
public class OnlineStoreDriver {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in );
        System.out.println("Enter the product name to be purchased");
        String productName = scanner.nextLine();
        System.out.println("Enter the price of the product");
        double price = scanner.nextDouble();
        System.out.println("Enter the quantity");
        int quantity = scanner.nextInt();
        System.out.println("Enter the tax of the product in percentage");
        double taxPercentage = scanner.nextDouble();
        System.out.println("Enter the shipping cost: $");
        double ShippingCost = scanner.nextDouble();
        Product product1 = new Product(productName,price,quantity,taxPercentage,ShippingCost);
        System.out.println("***************************************************************");
        System.out.println("***The Product1 details are : ***");
        System.out.println(product1.toString());
        System.out.printf("Total Price of the Product including tax: $ %.2f%n" , product1.getcalcProductTotalPrice());
        System.out.printf("Final Price of the Product after applying discount: $ %.2f%n" , product1.getcalcProductFinalPrice());
        Product product2 = new Product();
        System.out.println("***************************************************************");
        System.out.println("***The details of the product2 object when no-arg construtor is invoked***");
        System.out.println(product2.toString());
        System.out.printf("Total Price of the Product including tax: $ %.2f%n" ,product2.getcalcProductTotalPrice());
        System.out.printf("Final Price of the Product after applying discount: $ %.2f%n" , product2.getcalcProductFinalPrice());
        product2.setproductName("Airpods");
        product2.setprice(250);
        product2.setquantity(4);
        product2.setshippingCost(28.45);
        product2.settaxPercentage(12.32);
        System.out.println("***************************************************************");
        System.out.println("***The details of Product2 object after setting the values:");
        System.out.println(product2.toString());
        System.out.printf("Total Price of the Product including tax: $  %.2f%n", product2.getcalcProductTotalPrice());
        System.out.printf("Final Price of the Product after applying discount: $%.2f%n" , product2.getcalcProductFinalPrice());
        
        
        
        
    }
    
    
}
