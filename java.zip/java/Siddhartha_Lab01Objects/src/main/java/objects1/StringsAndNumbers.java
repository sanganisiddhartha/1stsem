/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects1;

/**
 *
 * @author S569434
 */
public class StringsAndNumbers {
    public static void main(String[] args) {
        String greet = "Hello Bearcats welcome to spring 2024 Object Oriented Programing class";
        String value = String.valueOf(greet);
        int length = greet.length();
        String substring = greet.substring(38,65);
        String intro = "My name is Siddhartha_Sangani";
        String favsubject = "My favorite programming language is python because";
        String reason = "it is easy to learn and use";
        String about = String.join(".",intro,favsubject,reason);
        //String replaced = about.setCharAt(80," ");
        String language = about.substring(66,73);
        String firstLab = "This is my first Java Lab Activity";
        String lowerLab = firstLab.toLowerCase();
        System.out.println(value);
        System.out.println("The size of the string is"+length);
        System.out.println(substring);
        System.out.println("Starts with Hello or not"+greet.startsWith("Hello"));
        System.out.println("End with programing or not"+greet.endsWith("programing"));
        System.out.println(about);
        System.out.println("The second occurance of the full stop in string is at position "+about.lastIndexOf("."));
        System.out.println("My favlanguage name from the string is"+language);
        System.out.println(language.repeat(5));
        //System.out.println(lowerLab);
        System.out.println("By using equals()"+firstLab.equals(lowerLab));
        System.out.println("By using equalsIgnoreCase() "+firstLab.equalsIgnoreCase(lowerLab));
        System.out.println("String after replacing all occurances of 'i' with 'x'"+firstLab.replaceAll("i", "x"));
        System.out.println("After trim"+firstLab.trim());
        System.out.println("rounded value is"+Math.round(Math.sqrt((Math.pow(9,3))+Math.pow(24,3))));
        double result1 = (Math.cos(Math.toRadians(60))*Math.cos(Math.toRadians(30)))+(Math.sin(Math.toRadians(60))*Math.sin(Math.toRadians(30)));
        System.out.println("cos60cos30 +sin60sin30 is:"+result1);
        double result2=Math.cos(Math.toRadians(60-30));
        System.out.println("cos(60-30) is:"+result2);
        System.out.println("Same Result");
        System.out.println("The ceil value of ???60???30 +???60??? 30 is:"+Math.ceil(result1));
        System.out.println("log of 92"+Math.log(95)+" and "+"log of 32:"+Math.log(32));
        int m = ((8-4)/(3-1));
        System.out.println("y="+m+"x+b");//intersection left
        
    }

    
}
