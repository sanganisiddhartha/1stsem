/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package edu.nwmissouri.S569434.arrayandarraylists;

import java.util.Scanner;

/**
* Class: 44542-04 Object Oriented Programming
* @author Siddhartha Sangani
* Description: Making sure everything works
* Due: 02/25/24
* I pledge that I have completed the programming assignment
independently.
* I have not copied the code from a student or any source.
* I have not given my code to any other student and will not share
this code with anyone under my circumstances.
*/

public class ArrayOps {
    /**
     * 
     * @param employeeAges
     * @param employeeNames 
     */
    public static void arrayOperations(int[]employeeAges,String[]employeeNames) {
        String b[];
        b = new String[employeeNames.length];
         b=employeeNames;
        System.out.println("***************ARRAY******************************************************************************************");
        System.out.println("***************LOADING EMPLOYEE AGES IS COMPLETE******************************************************************************************");
        System.out.println("***************LOADING EMPLOYEE NAMES IS COMPLETE******************************************************************************************");
        System.out.println("*************Printing elements of employeeAges and employeeNames arrays using a standard for loop*************");
        System.out.println("EmployeeAges array elements are:");
        
        for(int i=0;i<employeeAges.length;i++)
        {
            System.out.print(" "+employeeAges[i]);
        }
        System.out.println();
        System.out.println("EmployeeNames array elements are:");
        for(int i=0;i<employeeNames.length;i++)
        {
            System.out.print(" " +employeeNames[i]);
        }
        System.out.println();
        
       System.out.println("*************Printing elements of employeeAges and employeeNames arrays using a standard for loop*************");
       System.out.println("EmployeeAges array elements are:");
       for(int employeeAge : employeeAges)
        {
            System.out.print(" " +employeeAge);
        }
        System.out.println();
        System.out.println("EmployeeNames array elements are:");
        for (String employeeName : employeeNames) {
            System.out.print(" " +employeeName);
        }
        //System.out.println("***********************************Operations on the employeeAges array***********************************");
        System.out.println();
        System.out.println("\n***********************************Operations on the employeeAges array***********************************");
        System.out.println("length of the employeeAges array is:"+employeeAges.length);
        int sum=0;
        for(int i=0;i<employeeAges.length;i++)
        {
            sum+=employeeAges[i];
        }
        double avgAges= (double)sum/employeeAges.length;
        System.out.println("Average of all the ages in the employeeAges array is "+avgAges);
        Scanner scanner = new Scanner(System.in );
        System.out.println("Enter the target age to search in the employeeAges array:");
        int tAge = scanner.nextInt();
        int fIndex = -1;
        int lIndex = -1;
        int count =0;
        for(int i=0;i<employeeAges.length;i++)
        {
            if(employeeAges[i]==tAge)
            {
                ++count;
                if(count==1)
                {
                    fIndex=i;
                }
                lIndex = i;
            }
        }
        //if(fIndex!=1)
        
            System.out.println("Output: ["+fIndex+","+lIndex+"]");
        
        System.out.println("Enter the age to find its occurrence(s) in employeeAges array:");
        int fAge = scanner.nextInt();
        int occ=0;
        for(int i =0;i<employeeAges.length;i++)
        {
            if(fAge==employeeAges[i])
            {
                occ++;
            }
        }
        //Scanner scanner = new Scanner(System.in );
        
        System.out.println("Number of occurrences of the element"+fAge+ "in employeeAges array is: "+occ);
        System.out.println("Enter the position between 0 and 5, where you want to replace the element in employeeAges array:");
        int index = scanner.nextInt();
        System.out.println("Enter the element you want to replace with: ");
        int newVal = scanner.nextInt();
        for(int i=0;i<=5&&i<employeeAges.length;i++)
        {
            if(i==index)
            {
                employeeAges[i]=newVal;
            }     
        }
        System.out.println("After replacement the employeeAges array elements are:");
        for(int employeeAge : employeeAges)
        {
            System.out.print(" "+employeeAge);
        }
        System.out.println();
        int youngestAge = Integer.MAX_VALUE;
        int secondYoungestAge = Integer.MAX_VALUE;
        for (int age : employeeAges) {
            if (age < youngestAge) {
                secondYoungestAge = youngestAge;
                youngestAge = age;
            } else if (age < secondYoungestAge && age != youngestAge) {
                secondYoungestAge = age;
            }
        }
        System.out.println("Second youngest age in the employeeAges array (assuming the youngest age isn't repeated) is: " + secondYoungestAge);
        //employeeNames Array
        System.out.println("*********************************Operations on the employeeNames array**********************************");
        
        //String a[] = new String[b.length];
        // b=a;
        for (String eName : employeeNames) {
            System.out.println("The length of "+eName+" is:"+eName.length());
        }
        
        System.out.println("Enter the character to remove in each element in employeeNames array: ");
         char removeChar = scanner.next().charAt(0); // Index 0 instead of 1
         //String b[] = new String[employeeNames.length];
         //b=employeeNames;
        for (int i = 0; i < employeeNames.length; i++) {
            if (employeeNames[i].length() > 1) { 
                employeeNames[i] = employeeNames[i].replace(Character.toString(removeChar), "");
            } else {

            }
        }
        System.out.println();
        System.out.println("After removing the given character : ");
        for(String name : employeeNames)
        {
            System.out.print(name+" ");
        }
        System.out.println();
        System.out.println("Reversing each element in array employeeNames array: ");
//        for(String name : a)
//        {
//            System.out.print(name+" ");
//        }
       // System.out.println("Original elements of employeeNames array in reverse order: ");
            for (int i =0;i < b.length ; i++) {
            StringBuilder reversed = new StringBuilder(b[i]);
            System.out.print(reversed.reverse().toString() );
                    }
            System.out.println();
        //2D Array
        
                //Scanner scanner = new Scanner(System.in);
                System.out.println("****************************************Matrix addition*****************************************");
                System.out.println("Please enter the columns in the matrix ");
                int m1 = scanner.nextInt();
                System.out.println("Please enter the columns in the matrix ");
                int n1 = scanner.nextInt();
                int[][] matrix1 = new int[m1][n1];
                //System.out.println("Matrix:");
                /**public static void fillMatrix(int[][] matrix1, Scanner scanner) {
                    for (int i = 0; i < matrix1.length; i++) {
                        for (int j = 0; j < matrix1[i].length; j++) {
                            System.out.print("Enter value at position [" + i + "][" + j + "]: ");
                            matrix1[i][j] = scanner.nextInt();
                        }
                    }
                }**/

                    for (int i = 0; i < matrix1.length; i++) {
                        for (int j = 0; j < matrix1[0].length; j++) {
                            System.out.print("Enter Matrix 1 [" + i + "][" + j + "] element: ");
                            matrix1[i][j] = scanner.nextInt();
                            //System.out.print("");
                        }
                        //System.out.println(); 
                    }
                //System.out.println("Enter the number of rows for matrix 2:");
                //int m2 = scanner.nextInt();
                //System.out.println("Enter the number of columns for matrix 2:");
                //int n2 = scanner.nextInt();
                int[][] matrix2 = new int[m1][n1];
                for (int i = 0; i < matrix2.length; i++) {
                        for (int j = 0; j < matrix2[0].length; j++) {
                            System.out.print("Enter Matrix 2 [" + i + "][" + j + "] element: ");
                            matrix2[i][j] = scanner.nextInt();
                            //System.out.print("");
                        }
                        //System.out.println(); 
                    }
                System.out.println("First Matrix:");
                printMatrix(matrix1);
                System.out.println("Second Matrix:");
                printMatrix(matrix2);
                int[][] sumMatrix = addMatrices(matrix1, matrix2);
                System.out.println("Sum of Matrices:");
                printMatrix(sumMatrix);
    }
        private static void printMatrix(int[][] matrix) 
        {
                for (int i = 0; i < matrix.length; i++)
                {
                    for (int j = 0; j < matrix[0].length; j++)
                    {
                        System.out.print(matrix[i][j] + "\t ");
                    }
                    System.out.println();
                }
            }
/**
 * 
 * @param matrix1
 * @param matrix2
 * @return 
 */
    private static int[][] addMatrices(int[][] matrix1, int[][] matrix2) {
        int rows = matrix1.length;
        int cols = matrix1[0].length;
        int[][] sumMatrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sumMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }
        return sumMatrix;
    }
    }

    

   


